import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/core/di/injection_container.dart';
import 'package:fitness_planner/core/router/app_router.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/firebase_options.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';
import 'package:fitness_planner/presentation/blocs/ai/ai_bloc.dart';
import 'package:fitness_planner/presentation/blocs/progress/progress_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await initDependencies();
  runApp(const FitnessApp());
}

class FitnessApp extends StatelessWidget {
  const FitnessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (_) => sl<AuthBloc>()..add(AuthStarted()),
        ),
        BlocProvider<WorkoutBloc>(
          create: (_) => sl<WorkoutBloc>(),
        ),
        BlocProvider<AiBloc>(
          create: (_) => sl<AiBloc>(),
        ),
        BlocProvider<ProgressBloc>(
          create: (_) => sl<ProgressBloc>(),
        ),
      ],
      child: BlocBuilder<AuthBloc, AuthState>(
        builder: (context, _) {
          final router = AppRouter.router(context.read<AuthBloc>());
          return MaterialApp.router(
            title: 'Fitness Planner',
            theme: AppTheme.darkTheme,
            routerConfig: router,
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}
