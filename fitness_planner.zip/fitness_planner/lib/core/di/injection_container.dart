import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fitness_planner/data/datasources/ai_datasource.dart';
import 'package:fitness_planner/data/datasources/firebase_auth_datasource.dart';
import 'package:fitness_planner/data/datasources/firestore_datasource.dart';
import 'package:fitness_planner/data/repositories/ai_repository_impl.dart';
import 'package:fitness_planner/data/repositories/auth_repository_impl.dart';
import 'package:fitness_planner/data/repositories/exercise_repository_impl.dart';
import 'package:fitness_planner/data/repositories/progress_repository_impl.dart';
import 'package:fitness_planner/data/repositories/user_repository_impl.dart';
import 'package:fitness_planner/data/repositories/workout_repository_impl.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';
import 'package:fitness_planner/domain/repositories/auth_repository.dart';
import 'package:fitness_planner/domain/repositories/exercise_repository.dart';
import 'package:fitness_planner/domain/repositories/progress_repository.dart';
import 'package:fitness_planner/domain/repositories/user_repository.dart';
import 'package:fitness_planner/domain/repositories/workout_repository.dart';
import 'package:fitness_planner/domain/usecases/ai/generate_workout_plan_usecase.dart';
import 'package:fitness_planner/domain/usecases/ai/get_daily_tip_usecase.dart';
import 'package:fitness_planner/domain/usecases/ai/get_improvement_suggestions_usecase.dart';
import 'package:fitness_planner/domain/usecases/ai/get_diet_suggestions_usecase.dart';
import 'package:fitness_planner/domain/usecases/auth/sign_in_usecase.dart';
import 'package:fitness_planner/domain/usecases/auth/sign_up_usecase.dart';
import 'package:fitness_planner/domain/usecases/progress/add_progress_entry_usecase.dart';
import 'package:fitness_planner/domain/usecases/workout/complete_workout_usecase.dart';
import 'package:fitness_planner/domain/usecases/workout/create_workout_usecase.dart';
import 'package:fitness_planner/domain/usecases/workout/get_workouts_by_day_usecase.dart';
import 'package:fitness_planner/presentation/blocs/ai/ai_bloc.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/progress/progress_bloc.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';
import 'package:get_it/get_it.dart';

final sl = GetIt.instance;

Future<void> initDependencies() async {
  // ─── External ─────────────────────────────────────────────────
  sl.registerLazySingleton<FirebaseAuth>(() => FirebaseAuth.instance);
  sl.registerLazySingleton<FirebaseFirestore>(() => FirebaseFirestore.instance);
  sl.registerLazySingleton<Dio>(() => Dio());

  // ─── Data Sources ─────────────────────────────────────────────
  sl.registerLazySingleton<FirebaseAuthDataSource>(
    () => FirebaseAuthDataSourceImpl(sl()),
  );
  sl.registerLazySingleton<FirestoreDataSource>(
    () => FirestoreDataSourceImpl(sl()),
  );
  sl.registerLazySingleton<AiDataSource>(
    () => OpenRouterDataSource(sl()),
  );

  // ─── Repositories ─────────────────────────────────────────────
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(sl(), sl()),
  );
  sl.registerLazySingleton<UserRepository>(
    () => UserRepositoryImpl(sl()),
  );
  sl.registerLazySingleton<WorkoutRepository>(
    () => WorkoutRepositoryImpl(sl()),
  );
  sl.registerLazySingleton<ExerciseRepository>(
    () => ExerciseRepositoryImpl(sl()),
  );
  sl.registerLazySingleton<ProgressRepository>(
    () => ProgressRepositoryImpl(sl()),
  );
  sl.registerLazySingleton<AiRepository>(
    () => AiRepositoryImpl(sl(), sl()),
  );

  // ─── Use Cases — Auth ──────────────────────────────────────────
  sl.registerLazySingleton(() => SignInUseCase(sl()));
  sl.registerLazySingleton(() => SignUpUseCase(sl()));

  // ─── Use Cases — Workout ───────────────────────────────────────
  sl.registerLazySingleton(() => CreateWorkoutUseCase(sl()));
  sl.registerLazySingleton(() => GetWorkoutsByDayUseCase(sl()));
  sl.registerLazySingleton(() => CompleteWorkoutUseCase(sl()));

  // ─── Use Cases — AI ────────────────────────────────────────────
  sl.registerLazySingleton(() => GenerateWorkoutPlanUseCase(sl()));
  sl.registerLazySingleton(() => GetImprovementSuggestionsUseCase(sl()));
  sl.registerLazySingleton(() => GetDailyTipUseCase(sl()));
  sl.registerLazySingleton(() => GetDietSuggestionsUseCase(sl()));

  // ─── Use Cases — Progress ──────────────────────────────────────
  sl.registerLazySingleton(() => AddProgressEntryUseCase(sl()));

  // ─── BLoCs (factory = new instance each time) ─────────────────
  sl.registerFactory(
    () => AuthBloc(
      signInUseCase: sl(),
      signUpUseCase: sl(),
      authRepository: sl(),
    ),
  );
  sl.registerFactory(
    () => WorkoutBloc(
      workoutRepository: sl(),
      createWorkoutUseCase: sl(),
      completeWorkoutUseCase: sl(),
      getWorkoutsByDayUseCase: sl(),
    ),
  );
  sl.registerFactory(
    () => AiBloc(
      generateWorkoutPlanUseCase: sl(),
      getImprovementSuggestionsUseCase: sl(),
      getDailyTipUseCase: sl(),
      aiRepository: sl(),
    ),
  );
  sl.registerFactory(
    () => ProgressBloc(
      progressRepository: sl(),
      addProgressEntryUseCase: sl(),
    ),
  );
}
