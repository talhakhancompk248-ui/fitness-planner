import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/screens/auth/login_screen.dart';
import 'package:fitness_planner/presentation/screens/auth/register_screen.dart';
import 'package:fitness_planner/presentation/screens/auth/onboarding_screen.dart';
import 'package:fitness_planner/presentation/screens/home/home_screen.dart';
import 'package:fitness_planner/presentation/screens/workout/workout_detail_screen.dart';
import 'package:fitness_planner/presentation/screens/workout/create_workout_screen.dart';
import 'package:fitness_planner/presentation/screens/exercise/exercise_library_screen.dart';
import 'package:fitness_planner/presentation/screens/progress/progress_screen.dart';
import 'package:fitness_planner/presentation/screens/ai/ai_coach_screen.dart';
import 'package:fitness_planner/presentation/screens/profile/profile_screen.dart';
import 'package:fitness_planner/presentation/screens/main/main_shell.dart';

class AppRouter {
  static GoRouter router(AuthBloc authBloc) => GoRouter(
        initialLocation: '/login',
        redirect: (context, state) {
          final authState = authBloc.state;
          final isAuth = authState is AuthAuthenticated;
          final loc = state.matchedLocation;
          final isOnAuth =
              loc == '/login' || loc == '/register' || loc == '/onboarding';

          if (!isAuth && !isOnAuth) return '/login';
          if (isAuth && isOnAuth) return '/home';
          return null;
        },
        refreshListenable: GoRouterRefreshStream(authBloc.stream),
        routes: [
          // ─── Auth Routes (no shell) ───────────────────────────
          GoRoute(
            path: '/login',
            builder: (_, __) => const LoginScreen(),
          ),
          GoRoute(
            path: '/register',
            builder: (_, __) => const RegisterScreen(),
          ),
          GoRoute(
            path: '/onboarding',
            builder: (_, __) => const OnboardingScreen(),
          ),

          // ─── Workout Routes (no shell — full screen) ──────────
          // IMPORTANT: /workout/create must come BEFORE /workout/:id
          // so the literal "create" is not treated as a path parameter
          GoRoute(
            path: '/workout/create',
            builder: (_, __) => const CreateWorkoutScreen(),
          ),
          GoRoute(
            path: '/workout/:id',
            builder: (context, state) => WorkoutDetailScreen(
              workoutId: state.pathParameters['id']!,
            ),
          ),

          // ─── Main Shell Routes (bottom nav) ───────────────────
          ShellRoute(
            builder: (context, state, child) => MainShell(child: child),
            routes: [
              GoRoute(
                path: '/home',
                builder: (_, __) => const HomeScreen(),
              ),
              GoRoute(
                path: '/exercises',
                builder: (_, __) => const ExerciseLibraryScreen(),
              ),
              GoRoute(
                path: '/progress',
                builder: (_, __) => const ProgressScreen(),
              ),
              GoRoute(
                path: '/ai-coach',
                builder: (_, __) => const AiCoachScreen(),
              ),
              GoRoute(
                path: '/profile',
                builder: (_, __) => const ProfileScreen(),
              ),
            ],
          ),
        ],
      );
}

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    notifyListeners();
    _sub = stream.listen((_) => notifyListeners());
  }
  late final dynamic _sub;

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
