class AppConstants {
  AppConstants._();

  // OpenRouter AI
  static const String openRouterBaseUrl = 'https://openrouter.ai/api/v1';
  static const String openRouterApiKey = 'YOUR_OPENROUTER_API_KEY'; // Replace
  static const String aiModel = 'mistralai/mistral-7b-instruct';

  // Firestore Collections
  static const String usersCollection = 'users';
  static const String workoutsCollection = 'workouts';
  static const String exercisesCollection = 'exercises';
  static const String logsCollection = 'workout_logs';
  static const String progressCollection = 'progress';
  static const String tipsCollection = 'ai_tips';
  static const String chatCollection = 'ai_chat_history';

  // Hive Boxes
  static const String exerciseBox = 'exercises_box';
  static const String settingsBox = 'settings_box';

  // Days of the Week
  static const List<String> weekDays = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  // Muscle Groups
  static const List<String> muscleGroups = [
    'Chest',
    'Back',
    'Shoulders',
    'Arms',
    'Core',
    'Legs',
    'Glutes',
    'Full Body',
    'Cardio',
  ];

  // Fitness Goals
  static const String goalLoseWeight = 'Lose Weight';
  static const String goalGainMuscle = 'Gain Muscle';
  static const String goalMaintain = 'Maintain';

  // Equipment Types
  static const List<String> equipmentTypes = [
    'Bodyweight',
    'Dumbbell',
    'Barbell',
    'Machine',
    'Cable',
    'Resistance Band',
    'Kettlebell',
  ];

  // Difficulty Levels
  static const String diffBeginner = 'Beginner';
  static const String diffIntermediate = 'Intermediate';
  static const String diffAdvanced = 'Advanced';
}
