import 'package:intl/intl.dart';

class AppDateUtils {
  AppDateUtils._();

  static String formatDate(DateTime date) =>
      DateFormat('MMM dd, yyyy').format(date);

  static String formatShortDate(DateTime date) =>
      DateFormat('MMM dd').format(date);

  static String formatTime(DateTime date) => DateFormat('hh:mm a').format(date);

  static String formatDay(DateTime date) => DateFormat('EEEE').format(date);

  static String formatShortDay(DateTime date) => DateFormat('EEE').format(date);

  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  static DateTime startOfWeek(DateTime date) {
    final weekday = date.weekday;
    return date.subtract(Duration(days: weekday - 1));
  }

  static List<DateTime> getCurrentWeekDays() {
    final now = DateTime.now();
    final start = startOfWeek(now);
    return List.generate(7, (i) => start.add(Duration(days: i)));
  }

  static int daysBetween(DateTime from, DateTime to) =>
      to.difference(from).inDays;

  static String timeAgo(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'just now';
  }
}
