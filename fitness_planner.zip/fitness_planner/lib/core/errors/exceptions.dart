/// Base class for all app-level exceptions.
/// Every data source layer throws a subclass of [AppException].
abstract class AppException implements Exception {
  final String message;
  final String? code;

  const AppException(this.message, {this.code});

  @override
  String toString() =>
      '$runtimeType: $message${code != null ? ' (code: $code)' : ''}';
}

/// Thrown when a Firebase / REST API server call fails.
class ServerException extends AppException {
  const ServerException(super.message, {super.code});
}

/// Thrown when Firebase Auth operations fail.
class AuthException extends AppException {
  const AuthException(super.message, {super.code});
}

/// Thrown when there is no internet / network connection.
class NetworkException extends AppException {
  const NetworkException(super.message, {super.code});
}

/// Thrown when reading from / writing to local cache (Hive, SharedPrefs) fails.
class CacheException extends AppException {
  const CacheException(super.message, {super.code});
}

/// Thrown when required data is not found in the data source.
class NotFoundException extends AppException {
  const NotFoundException(super.message, {super.code});
}

/// Thrown when input validation fails at the data layer.
class ValidationException extends AppException {
  const ValidationException(super.message, {super.code});
}

/// Thrown when the user does not have permission to perform an action.
class PermissionException extends AppException {
  const PermissionException(super.message, {super.code});
}

/// Thrown when an AI / OpenRouter API call fails.
class AiException extends AppException {
  const AiException(super.message, {super.code});
}

/// Thrown when a file or media operation fails (e.g. image upload).
class FileException extends AppException {
  const FileException(super.message, {super.code});
}

/// Thrown when an operation times out.
class TimeoutException extends AppException {
  const TimeoutException(super.message, {super.code});
}
