import 'package:equatable/equatable.dart';

/// Base class for all domain-layer failures.
/// Repositories catch [AppException]s and convert them to [Failure] subclasses
/// before returning them through [Result].
abstract class Failure extends Equatable {
  final String message;
  final String? code;

  const Failure(this.message, {this.code});

  @override
  List<Object?> get props => [message, code];

  @override
  String toString() =>
      '$runtimeType: $message${code != null ? ' ($code)' : ''}';
}

/// A Firebase Firestore or REST API call returned an error.
class ServerFailure extends Failure {
  const ServerFailure(super.message, {super.code});
}

/// A Firebase Auth operation failed (wrong password, user not found, etc.).
class AuthFailure extends Failure {
  const AuthFailure(super.message, {super.code});
}

/// The device has no internet connection or the request timed out.
class NetworkFailure extends Failure {
  const NetworkFailure(super.message, {super.code});
}

/// Reading from or writing to the local cache (Hive / SharedPreferences) failed.
class CacheFailure extends Failure {
  const CacheFailure(super.message, {super.code});
}

/// The requested resource does not exist.
class NotFoundFailure extends Failure {
  const NotFoundFailure(super.message, {super.code});
}

/// Input provided by the user or the system failed validation rules.
class ValidationFailure extends Failure {
  const ValidationFailure(super.message, {super.code});
}

/// The current user does not have permission to perform this action.
class PermissionFailure extends Failure {
  const PermissionFailure(super.message, {super.code});
}

/// An OpenRouter / AI API call failed.
class AiFailure extends Failure {
  const AiFailure(super.message, {super.code});
}

/// A file or media operation failed.
class FileFailure extends Failure {
  const FileFailure(super.message, {super.code});
}

/// An operation took too long and was cancelled.
class TimeoutFailure extends Failure {
  const TimeoutFailure(super.message, {super.code});
}

/// A catch-all for unexpected errors that do not fit any other category.
class UnexpectedFailure extends Failure {
  const UnexpectedFailure(super.message, {super.code});
}
