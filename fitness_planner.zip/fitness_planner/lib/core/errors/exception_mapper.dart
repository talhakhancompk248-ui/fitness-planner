import 'package:firebase_auth/firebase_auth.dart' show FirebaseAuthException;
import 'package:dio/dio.dart' show DioException, DioExceptionType;
import 'package:fitness_planner/core/errors/exceptions.dart';
import 'package:fitness_planner/core/errors/failures.dart';

/// Converts any caught object into a [Failure] suitable for the domain layer.
///
/// Usage inside a repository:
/// ```dart
/// try {
///   ...
/// } catch (e) {
///   return Result.error(ExceptionMapper.toFailure(e));
/// }
/// ```
class ExceptionMapper {
  ExceptionMapper._();

  /// Maps any exception type to the correct [Failure] subclass.
  static Failure toFailure(Object error) {
    // ── Our own typed exceptions (thrown by data sources) ──────────
    if (error is AuthException) {
      return AuthFailure(error.message, code: error.code);
    }
    if (error is ServerException) {
      return ServerFailure(error.message, code: error.code);
    }
    if (error is NetworkException) {
      return NetworkFailure(error.message, code: error.code);
    }
    if (error is CacheException) {
      return CacheFailure(error.message, code: error.code);
    }
    if (error is NotFoundException) {
      return NotFoundFailure(error.message, code: error.code);
    }
    if (error is ValidationException) {
      return ValidationFailure(error.message, code: error.code);
    }
    if (error is PermissionException) {
      return PermissionFailure(error.message, code: error.code);
    }
    if (error is AiException) {
      return AiFailure(error.message, code: error.code);
    }
    if (error is FileException) {
      return FileFailure(error.message, code: error.code);
    }
    if (error is TimeoutException) {
      return TimeoutFailure(error.message, code: error.code);
    }

    // ── Firebase Auth exceptions (raw, if not wrapped) ─────────────
    if (error is FirebaseAuthException) {
      return AuthFailure(
        _friendlyFirebaseAuthMessage(error.code),
        code: error.code,
      );
    }

    // ── Dio / HTTP exceptions ───────────────────────────────────────
    if (error is DioException) {
      return _mapDioException(error);
    }

    // ── Dart built-ins ─────────────────────────────────────────────
    if (error is FormatException) {
      return ServerFailure('Invalid data format: ${error.message}');
    }

    // ── Fallback ───────────────────────────────────────────────────
    return UnexpectedFailure(error.toString());
  }

  // ── Private helpers ──────────────────────────────────────────────

  static Failure _mapDioException(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return const TimeoutFailure(
          'Request timed out. Please check your connection.',
        );
      case DioExceptionType.connectionError:
        return const NetworkFailure(
          'No internet connection. Please try again.',
        );
      case DioExceptionType.badResponse:
        final statusCode = e.response?.statusCode;
        final message = e.response?.data?['error']?['message'] as String? ??
            e.message ??
            'Server error';
        if (statusCode == 401 || statusCode == 403) {
          return AuthFailure(message, code: statusCode.toString());
        }
        if (statusCode == 404) {
          return NotFoundFailure(message, code: statusCode.toString());
        }
        if (statusCode == 429) {
          return ServerFailure(
            'Too many requests. Please wait a moment.',
            code: '429',
          );
        }
        return ServerFailure(message, code: statusCode.toString());
      default:
        return ServerFailure(e.message ?? 'An unexpected error occurred.');
    }
  }

  static String _friendlyFirebaseAuthMessage(String? code) {
    switch (code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password. Please try again.';
      case 'invalid-email':
        return 'The email address is not valid.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'email-already-in-use':
        return 'An account already exists with this email.';
      case 'operation-not-allowed':
        return 'This sign-in method is not enabled.';
      case 'weak-password':
        return 'Password is too weak. Use at least 6 characters.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your connection.';
      case 'requires-recent-login':
        return 'Please sign in again to continue.';
      case 'invalid-credential':
        return 'Email or password is incorrect.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }
}
