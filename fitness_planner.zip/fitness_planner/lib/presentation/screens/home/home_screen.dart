import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/core/utils/date_utils.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';
import 'package:fitness_planner/presentation/blocs/ai/ai_bloc.dart';
import 'package:fitness_planner/presentation/widgets/home/daily_tip_card.dart';
import 'package:fitness_planner/presentation/widgets/home/today_workout_card.dart';
import 'package:fitness_planner/presentation/widgets/home/weekly_overview_widget.dart';
import 'package:fitness_planner/presentation/widgets/home/stats_row_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Initialize blocs based on current auth state
    _initializeBlocs();
  }

  void _initializeBlocs() {
    final authState = context.read<AuthBloc>().state;
    if (authState is AuthAuthenticated) {
      context.read<WorkoutBloc>().add(WorkoutSubscribed(authState.user.id));
      context.read<AiBloc>().add(AiDailyTipRequested(authState.user));
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, authState) {
        if (authState is! AuthAuthenticated) return const SizedBox.shrink();
        final user = authState.user;

        return Scaffold(
          backgroundColor: AppTheme.bgDark,
          body: CustomScrollView(
            slivers: [
              SliverAppBar(
                floating: true,
                backgroundColor: AppTheme.bgDark,
                elevation: 0,
                title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _getGreeting(),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    Text(
                      user.name,
                      style: Theme.of(context).textTheme.headlineLarge,
                    ),
                  ],
                ),
                actions: [
                  IconButton(
                    onPressed: () => context.go('/workout/create'),
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.primary,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.add,
                        color: AppTheme.bgDark,
                        size: 20,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Stats Row
                      BlocBuilder<WorkoutBloc, WorkoutState>(
                        builder: (context, state) {
                          final workouts = state is WorkoutSuccess
                              ? state.workouts
                              : <WorkoutEntity>[];
                          return StatsRowWidget(workouts: workouts);
                        },
                      ),
                      const SizedBox(height: 20),

                      // Daily AI Tip
                      const DailyTipCard(),
                      const SizedBox(height: 20),

                      // Weekly Overview
                      Text(
                        'This Week',
                        style: Theme.of(context).textTheme.headlineLarge,
                      ),
                      const SizedBox(height: 12),
                      BlocBuilder<WorkoutBloc, WorkoutState>(
                        builder: (context, state) {
                          final workouts = state is WorkoutSuccess
                              ? state.workouts
                              : <WorkoutEntity>[];
                          return WeeklyOverviewWidget(workouts: workouts);
                        },
                      ),
                      const SizedBox(height: 20),

                      // Today's Workouts
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Today's Plan",
                            style: Theme.of(context).textTheme.headlineLarge,
                          ),
                          Text(
                            AppDateUtils.formatShortDate(DateTime.now()),
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      BlocBuilder<WorkoutBloc, WorkoutState>(
                        builder: (context, state) {
                          if (state is WorkoutLoading) {
                            return const Center(
                              child: CircularProgressIndicator(
                                color: AppTheme.primary,
                              ),
                            );
                          }
                          if (state is WorkoutSuccess) {
                            final today =
                                AppDateUtils.formatDay(DateTime.now());
                            final todayWorkouts = state.workouts
                                .where((w) => w.targetDays.contains(today))
                                .toList();

                            if (todayWorkouts.isEmpty) {
                              return _buildRestDayCard(context);
                            }

                            return Column(
                              children: todayWorkouts
                                  .map((w) => TodayWorkoutCard(workout: w))
                                  .toList(),
                            );
                          }
                          return const SizedBox.shrink();
                        },
                      ),
                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good Morning,';
    if (hour < 17) return 'Good Afternoon,';
    return 'Good Evening,';
  }

  Widget _buildRestDayCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.bgCard,
            AppTheme.bgCardLight,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.hotel,
              color: AppTheme.primary,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Rest Day',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 4),
                Text(
                  'Recovery is part of progress. Enjoy your rest!',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
