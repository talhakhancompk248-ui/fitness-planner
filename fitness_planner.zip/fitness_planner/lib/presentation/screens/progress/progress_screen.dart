import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/core/utils/date_utils.dart';
import 'package:fitness_planner/domain/entities/progress_entry_entity.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/progress/progress_bloc.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  final _weightCtrl = TextEditingController();
  final _waistCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final authState = context.read<AuthBloc>().state;
    if (authState is AuthAuthenticated) {
      context.read<ProgressBloc>().add(ProgressSubscribed(authState.user.id));
    }
  }

  @override
  void dispose() {
    _weightCtrl.dispose();
    _waistCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(title: const Text('Progress Tracker')),
      body: BlocBuilder<ProgressBloc, ProgressState>(
        builder: (context, state) {
          // Use corrected ProgressLoading / ProgressLoaded state names
          if (state is ProgressLoading) {
            return const Center(
              child: CircularProgressIndicator(color: AppTheme.primary),
            );
          }

          final entries =
              state is ProgressLoaded ? state.entries : <ProgressEntryEntity>[];

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Log Entry Card
                _buildLogCard(context),
                const SizedBox(height: 20),

                if (state is ProgressError)
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.error.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border:
                          Border.all(color: AppTheme.error.withOpacity(0.4)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline,
                            color: AppTheme.error, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            state.message,
                            style: const TextStyle(color: AppTheme.error),
                          ),
                        ),
                      ],
                    ),
                  ),

                if (entries.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text('Weight History',
                      style: Theme.of(context).textTheme.headlineLarge),
                  const SizedBox(height: 12),
                  _buildWeightChart(entries),
                  const SizedBox(height: 20),
                  _buildStatsSummary(context, entries),
                  const SizedBox(height: 20),
                  Text('All Entries',
                      style: Theme.of(context).textTheme.headlineLarge),
                  const SizedBox(height: 12),
                  _buildEntryList(context, entries),
                ] else if (state is ProgressLoaded) ...[
                  const SizedBox(height: 40),
                  Center(
                    child: Column(
                      children: [
                        Icon(Icons.show_chart,
                            color: AppTheme.textMuted, size: 60),
                        const SizedBox(height: 16),
                        Text(
                          'No entries yet.\nLog your first measurement above!',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 100),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildLogCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.add_chart,
                    color: AppTheme.primary, size: 20),
              ),
              const SizedBox(width: 10),
              Text('Log Today',
                  style: Theme.of(context).textTheme.headlineSmall),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _weightCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(color: AppTheme.textPrimary),
                  decoration: const InputDecoration(
                    labelText: 'Weight (kg)',
                    prefixIcon: Icon(Icons.monitor_weight_outlined,
                        color: AppTheme.textMuted),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _waistCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(color: AppTheme.textPrimary),
                  decoration: const InputDecoration(
                    labelText: 'Waist (cm)',
                    prefixIcon:
                        Icon(Icons.straighten, color: AppTheme.textMuted),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _notesCtrl,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(
              labelText: 'Notes (optional)',
              prefixIcon: Icon(Icons.notes, color: AppTheme.textMuted),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.save_outlined),
              label: const Text('Save Entry'),
              onPressed: _logEntry,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeightChart(List<ProgressEntryEntity> entries) {
    final weightEntries = entries.where((e) => e.weight != null).toList();
    if (weightEntries.isEmpty) return const SizedBox.shrink();

    final minY =
        weightEntries.map((e) => e.weight!).reduce((a, b) => a < b ? a : b) - 2;
    final maxY =
        weightEntries.map((e) => e.weight!).reduce((a, b) => a > b ? a : b) + 2;

    return Container(
      height: 200,
      padding: const EdgeInsets.fromLTRB(8, 16, 16, 8),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: LineChart(
        LineChartData(
          minY: minY,
          maxY: maxY,
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (_) =>
                const FlLine(color: Color(0xFF1E2940), strokeWidth: 1),
          ),
          titlesData: FlTitlesData(
            rightTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: (weightEntries.length / 4).ceilToDouble(),
                getTitlesWidget: (value, _) {
                  final idx = value.toInt();
                  if (idx < 0 || idx >= weightEntries.length) {
                    return const SizedBox.shrink();
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      AppDateUtils.formatShortDate(weightEntries[idx].date),
                      style: const TextStyle(
                          color: AppTheme.textMuted, fontSize: 9),
                    ),
                  );
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 44,
                getTitlesWidget: (value, _) => Text(
                  '${value.toInt()}kg',
                  style:
                      const TextStyle(color: AppTheme.textMuted, fontSize: 10),
                ),
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              spots: weightEntries.asMap().entries.map((e) {
                return FlSpot(e.key.toDouble(), e.value.weight!);
              }).toList(),
              isCurved: true,
              color: AppTheme.primary,
              barWidth: 2.5,
              belowBarData: BarAreaData(
                show: true,
                color: AppTheme.primary.withOpacity(0.08),
              ),
              dotData: FlDotData(
                show: true,
                getDotPainter: (_, __, ___, ____) => FlDotCirclePainter(
                  radius: 3,
                  color: AppTheme.primary,
                  strokeWidth: 0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsSummary(
      BuildContext context, List<ProgressEntryEntity> entries) {
    final weightEntries = entries.where((e) => e.weight != null).toList();
    if (weightEntries.isEmpty) return const SizedBox.shrink();

    final latest = weightEntries.last.weight!;
    final first = weightEntries.first.weight!;
    final change = latest - first;
    final daysSince = AppDateUtils.daysBetween(
        weightEntries.first.date, weightEntries.last.date);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Row(
        children: [
          _statItem(context, 'Current', '${latest.toStringAsFixed(1)}kg',
              AppTheme.primary),
          _statItem(context, 'Starting', '${first.toStringAsFixed(1)}kg',
              AppTheme.textSecondary),
          _statItem(
            context,
            'Change',
            '${change >= 0 ? '+' : ''}${change.toStringAsFixed(1)}kg',
            change <= 0 ? AppTheme.success : AppTheme.warning,
          ),
          _statItem(context, 'Days', '$daysSince', AppTheme.info),
        ],
      ),
    );
  }

  Widget _statItem(
      BuildContext context, String label, String value, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
                color: color, fontSize: 16, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 4),
          Text(label, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }

  Widget _buildEntryList(
      BuildContext context, List<ProgressEntryEntity> entries) {
    final reversed = entries.reversed.toList();
    return Column(
      children: reversed.take(10).map((entry) {
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF1E2940)),
          ),
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    AppDateUtils.formatDate(entry.date),
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  if (entry.notes != null && entry.notes!.isNotEmpty)
                    Text(entry.notes!,
                        style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
              const Spacer(),
              if (entry.weight != null)
                _entryChip(
                    '${entry.weight!.toStringAsFixed(1)}kg', AppTheme.primary),
              if (entry.waistCm != null) ...[
                const SizedBox(width: 6),
                _entryChip(
                    '${entry.waistCm!.toStringAsFixed(1)}cm', AppTheme.info),
              ],
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => context
                    .read<ProgressBloc>()
                    .add(ProgressEntryDeleted(entry.id)),
                child: const Icon(Icons.delete_outline,
                    color: AppTheme.textMuted, size: 18),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _entryChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style:
            TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }

  void _logEntry() {
    final authState = context.read<AuthBloc>().state;
    if (authState is! AuthAuthenticated) return;

    final weight = double.tryParse(_weightCtrl.text.trim());
    final waist = double.tryParse(_waistCtrl.text.trim());

    if (weight == null && waist == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter at least weight or waist measurement'),
          backgroundColor: AppTheme.warning,
        ),
      );
      return;
    }

    context.read<ProgressBloc>().add(
          ProgressEntryAdded(
            userId: authState.user.id,
            weight: weight,
            waistCm: waist,
            notes:
                _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(),
          ),
        );

    _weightCtrl.clear();
    _waistCtrl.clear();
    _notesCtrl.clear();
    FocusScope.of(context).unfocus();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ Entry saved!'),
        backgroundColor: AppTheme.success,
        duration: Duration(seconds: 2),
      ),
    );
  }
}
