import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';

class MainShell extends StatelessWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  int _locationToIndex(String location) {
    if (location.startsWith('/home')) return 0;
    if (location.startsWith('/exercises')) return 1;
    if (location.startsWith('/progress')) return 2;
    if (location.startsWith('/ai-coach')) return 3;
    if (location.startsWith('/profile')) return 4;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    final currentIndex = _locationToIndex(location);

    return Scaffold(
      body: child,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          border: const Border(
            top: BorderSide(color: Color(0xFF1E2940), width: 1),
          ),
        ),
        child: NavigationBar(
          backgroundColor: AppTheme.bgCard,
          surfaceTintColor: Colors.transparent,
          selectedIndex: currentIndex,
          indicatorColor: AppTheme.primary.withOpacity(0.15),
          onDestinationSelected: (index) {
            switch (index) {
              case 0:
                context.go('/home');
              case 1:
                context.go('/exercises');
              case 2:
                context.go('/progress');
              case 3:
                context.go('/ai-coach');
              case 4:
                context.go('/profile');
            }
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home, color: AppTheme.primary),
              label: 'Home',
            ),
            NavigationDestination(
              icon: Icon(Icons.fitness_center_outlined),
              selectedIcon: Icon(Icons.fitness_center, color: AppTheme.primary),
              label: 'Exercises',
            ),
            NavigationDestination(
              icon: Icon(Icons.show_chart_outlined),
              selectedIcon: Icon(Icons.show_chart, color: AppTheme.primary),
              label: 'Progress',
            ),
            NavigationDestination(
              icon: Icon(Icons.psychology_outlined),
              selectedIcon: Icon(Icons.psychology, color: AppTheme.primary),
              label: 'AI Coach',
            ),
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person, color: AppTheme.primary),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}
