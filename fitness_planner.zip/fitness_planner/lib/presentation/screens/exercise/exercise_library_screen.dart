import 'package:flutter/material.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/domain/entities/exercise_entity.dart';
import 'package:fitness_planner/domain/repositories/exercise_repository.dart';
import 'package:fitness_planner/core/di/injection_container.dart';

class ExerciseLibraryScreen extends StatefulWidget {
  const ExerciseLibraryScreen({super.key});

  @override
  State<ExerciseLibraryScreen> createState() => _ExerciseLibraryScreenState();
}

class _ExerciseLibraryScreenState extends State<ExerciseLibraryScreen> {
  List<ExerciseEntity> _exercises = [];
  List<ExerciseEntity> _filtered = [];
  bool _loading = true;
  String _query = '';
  String? _selectedGroup;
  String? _selectedEquipment;

  @override
  void initState() {
    super.initState();
    _loadExercises();
  }

  Future<void> _loadExercises() async {
    final result = await sl<ExerciseRepository>().getExercises();
    result.fold(
      (_) => setState(() => _loading = false),
      (exercises) => setState(() {
        _exercises = exercises;
        _filtered = exercises;
        _loading = false;
      }),
    );
  }

  void _applyFilters() {
    setState(() {
      _filtered = _exercises.where((e) {
        final matchQuery = _query.isEmpty ||
            e.name.toLowerCase().contains(_query.toLowerCase());
        final matchGroup =
            _selectedGroup == null || e.muscleGroup == _selectedGroup;
        final matchEquip =
            _selectedEquipment == null || e.equipment == _selectedEquipment;
        return matchQuery && matchGroup && matchEquip;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Exercise Library'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: TextField(
              onChanged: (v) {
                _query = v;
                _applyFilters();
              },
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: InputDecoration(
                hintText: 'Search exercises...',
                prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted),
                filled: true,
                fillColor: AppTheme.bgCard,
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Muscle Group Filter
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [null, ...AppConstants.muscleGroups].map((g) {
                final isSelected = _selectedGroup == g;
                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedGroup = g);
                    _applyFilters();
                  },
                  child: Container(
                    margin: const EdgeInsets.only(right: 8, bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.primary : AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.primary
                            : const Color(0xFF1E2940),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        g ?? 'All',
                        style: TextStyle(
                          color: isSelected
                              ? AppTheme.bgDark
                              : AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          // Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Text(
                  '${_filtered.length} exercises',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          // List
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  )
                : _filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.search_off,
                              color: AppTheme.textMuted,
                              size: 60,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No exercises found',
                              style: Theme.of(context).textTheme.bodyLarge,
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: _filtered.length,
                        itemBuilder: (_, i) => _buildExerciseCard(_filtered[i]),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildExerciseCard(ExerciseEntity exercise) {
    final diffColor = {
          AppConstants.diffBeginner: AppTheme.success,
          AppConstants.diffIntermediate: AppTheme.warning,
          AppConstants.diffAdvanced: AppTheme.error,
        }[exercise.difficulty] ??
        AppTheme.textSecondary;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.fitness_center,
              color: AppTheme.primary,
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  exercise.name,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _tag(exercise.muscleGroup, AppTheme.info),
                    const SizedBox(width: 6),
                    _tag(exercise.equipment, AppTheme.textSecondary),
                    const SizedBox(width: 6),
                    _tag(exercise.difficulty, diffColor),
                  ],
                ),
              ],
            ),
          ),
          if (exercise.isCustom)
            const Icon(Icons.person, color: AppTheme.textMuted, size: 18),
        ],
      ),
    );
  }

  Widget _tag(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        label,
        style:
            TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600),
      ),
    );
  }
}
