import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/core/utils/date_utils.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/entities/workout_exercise_entity.dart';
import 'package:fitness_planner/domain/entities/workout_set_entity.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';

class WorkoutDetailScreen extends StatefulWidget {
  final String workoutId;
  const WorkoutDetailScreen({super.key, required this.workoutId});

  @override
  State<WorkoutDetailScreen> createState() => _WorkoutDetailScreenState();
}

class _WorkoutDetailScreenState extends State<WorkoutDetailScreen> {
  WorkoutEntity? _workout;

  @override
  void initState() {
    super.initState();
    _findWorkout();
  }

  void _findWorkout() {
    final state = context.read<WorkoutBloc>().state;
    if (state is WorkoutSuccess) {
      try {
        _workout = state.workouts.firstWhere((w) => w.id == widget.workoutId);
      } catch (_) {}
    }
  }

  void _markSetComplete(
    WorkoutExerciseEntity exercise,
    WorkoutSetEntity set,
  ) {
    if (_workout == null) return;
    final updatedSet = set.copyWith(isCompleted: !set.isCompleted);
    final updatedSets =
        exercise.sets.map((s) => s.id == set.id ? updatedSet : s).toList();
    final updatedExercise = WorkoutExerciseEntity(
      id: exercise.id,
      exercise: exercise.exercise,
      sets: updatedSets,
      notes: exercise.notes,
      orderIndex: exercise.orderIndex,
    );
    final updatedExercises = _workout!.exercises
        .map((e) => e.id == exercise.id ? updatedExercise : e)
        .toList();
    setState(() {
      _workout = _workout!.copyWith(exercises: updatedExercises);
    });
    context.read<WorkoutBloc>().add(WorkoutUpdated(_workout!));
  }

  void _completeWorkout() {
    if (_workout == null) return;
    context.read<WorkoutBloc>().add(WorkoutCompleted(_workout!));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('🎉 Workout completed! Great job!'),
        backgroundColor: AppTheme.success,
      ),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    if (_workout == null) {
      return Scaffold(
        backgroundColor: AppTheme.bgDark,
        appBar: AppBar(title: const Text('Workout')),
        body: const Center(
          child: Text(
            'Workout not found',
            style: TextStyle(color: AppTheme.textSecondary),
          ),
        ),
      );
    }

    final workout = _workout!;
    final isCompleted = workout.status == WorkoutStatus.completed;

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: CustomScrollView(
        slivers: [
          // Hero App Bar
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            backgroundColor: AppTheme.bgDark,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.primary.withOpacity(0.3),
                      AppTheme.bgDark,
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 80, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        workout.name,
                        style: Theme.of(context).textTheme.displaySmall,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          _infoChip(
                            '${workout.totalExercises} exercises',
                            Icons.fitness_center,
                          ),
                          const SizedBox(width: 8),
                          _infoChip(
                            workout.difficulty.name,
                            Icons.speed,
                          ),
                          if (workout.estimatedDuration != null) ...[
                            const SizedBox(width: 8),
                            _infoChip(
                              '${workout.estimatedDuration}min',
                              Icons.timer_outlined,
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Progress indicator
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${workout.completedExercises}/${workout.totalExercises} exercises',
                        style: Theme.of(context).textTheme.labelLarge,
                      ),
                      Text(
                        '${(workout.progressPercent * 100).toInt()}%',
                        style: const TextStyle(
                          color: AppTheme.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: workout.progressPercent,
                      backgroundColor: AppTheme.bgCardLight,
                      valueColor:
                          const AlwaysStoppedAnimation(AppTheme.primary),
                      minHeight: 8,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Exercise List
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final exercise = workout.exercises[index];
                return _buildExerciseCard(exercise);
              },
              childCount: workout.exercises.length,
            ),
          ),

          // Complete Button
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: isCompleted
                  ? Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.success.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: AppTheme.success.withOpacity(0.5),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.check_circle,
                              color: AppTheme.success),
                          const SizedBox(width: 8),
                          Text(
                            'Completed on ${AppDateUtils.formatDate(workout.completedAt!)}',
                            style: const TextStyle(color: AppTheme.success),
                          ),
                        ],
                      ),
                    )
                  : ElevatedButton.icon(
                      onPressed: _completeWorkout,
                      icon: const Icon(Icons.check),
                      label: const Text('Mark Workout Complete'),
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 52),
                      ),
                    ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 40)),
        ],
      ),
    );
  }

  Widget _buildExerciseCard(WorkoutExerciseEntity exercise) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: exercise.isCompleted
              ? AppTheme.success.withOpacity(0.4)
              : const Color(0xFF1E2940),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Exercise Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      '${exercise.orderIndex + 1}',
                      style: const TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        exercise.exercise.name,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      Text(
                        '${exercise.exercise.muscleGroup} • ${exercise.exercise.equipment}',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
                if (exercise.isCompleted)
                  const Icon(Icons.check_circle, color: AppTheme.success),
              ],
            ),
          ),
          // Sets Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _headerCell('Set'),
                _headerCell('Target'),
                _headerCell('Weight'),
                _headerCell('Done'),
              ],
            ),
          ),
          const Divider(color: Color(0xFF1E2940)),
          // Sets
          ...exercise.sets.map(
            (set) => _buildSetRow(exercise, set),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _headerCell(String text) {
    return Expanded(
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: AppTheme.textMuted,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildSetRow(WorkoutExerciseEntity exercise, WorkoutSetEntity set) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          // Set number
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: set.isCompleted
                    ? AppTheme.success.withOpacity(0.15)
                    : AppTheme.bgCardLight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '${set.setNumber}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color:
                      set.isCompleted ? AppTheme.success : AppTheme.textPrimary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Target reps
          Expanded(
            child: Text(
              set.targetReps != null ? '${set.targetReps} reps' : '—',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          // Target weight
          Expanded(
            child: Text(
              set.targetWeight != null ? '${set.targetWeight}kg' : 'BW',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          // Complete checkbox
          Expanded(
            child: GestureDetector(
              onTap: () => _markSetComplete(exercise, set),
              child: Center(
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color:
                        set.isCompleted ? AppTheme.success : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: set.isCompleted
                          ? AppTheme.success
                          : AppTheme.textMuted,
                    ),
                  ),
                  child: set.isCompleted
                      ? const Icon(Icons.check, color: Colors.white, size: 18)
                      : null,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoChip(String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppTheme.textSecondary, size: 14),
          const SizedBox(width: 4),
          Text(label,
              style:
                  const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }
}
