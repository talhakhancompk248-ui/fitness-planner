import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:uuid/uuid.dart';

import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/core/di/injection_container.dart';

import 'package:fitness_planner/domain/entities/exercise_entity.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/entities/workout_exercise_entity.dart';
import 'package:fitness_planner/domain/entities/workout_set_entity.dart';

import 'package:fitness_planner/domain/repositories/exercise_repository.dart';

import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';

import 'package:fitness_planner/presentation/widgets/common/gradient_button.dart';

class CreateWorkoutScreen extends StatefulWidget {
  const CreateWorkoutScreen({super.key});

  @override
  State<CreateWorkoutScreen> createState() => _CreateWorkoutScreenState();
}

class _CreateWorkoutScreenState extends State<CreateWorkoutScreen> {
  final _formKey = GlobalKey<FormState>();

  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();

  final _uuid = const Uuid();

  WorkoutDifficulty _difficulty = WorkoutDifficulty.beginner;

  final List<String> _selectedDays = [];
  final List<_ExerciseEntry> _exerciseEntries = [];

  int? _estimatedDuration;

  List<ExerciseEntity> _availableExercises = [];

  bool _loadingExercises = true;

  @override
  void initState() {
    super.initState();
    _loadExercises();
  }

  Future<void> _loadExercises() async {
    try {
      final result = await sl<ExerciseRepository>().getExercises();

      result.fold(
        (failure) {
          debugPrint('Failed to load exercises');
        },
        (exercises) {
          if (!mounted) return;

          setState(() {
            _availableExercises = exercises;
          });
        },
      );
    } catch (e) {
      debugPrint('Exercise loading error: $e');
    }

    if (mounted) {
      setState(() {
        _loadingExercises = false;
      });
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  void _addExercise(ExerciseEntity exercise) {
    final alreadyExists = _exerciseEntries.any(
      (e) => e.exercise.id == exercise.id,
    );

    if (alreadyExists) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Exercise already added'),
        ),
      );
      return;
    }

    setState(() {
      _exerciseEntries.add(
        _ExerciseEntry(
          id: _uuid.v4(),
          exercise: exercise,
          sets: [
            _SetEntry(
              id: _uuid.v4(),
              setNumber: 1,
              reps: 12,
              weight: 0,
            ),
          ],
        ),
      );
    });
  }

  void _addSet(_ExerciseEntry entry) {
    setState(() {
      entry.sets.add(
        _SetEntry(
          id: _uuid.v4(),
          setNumber: entry.sets.length + 1,
          reps: entry.sets.last.reps,
          weight: entry.sets.last.weight,
        ),
      );
    });
  }

  void _removeExercise(String entryId) {
    setState(() {
      _exerciseEntries.removeWhere(
        (e) => e.id == entryId,
      );
    });
  }

  void _saveWorkout() {
    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    if (_selectedDays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select at least one day'),
        ),
      );
      return;
    }

    if (_exerciseEntries.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please add at least one exercise'),
        ),
      );
      return;
    }

    final authState = context.read<AuthBloc>().state;

    if (authState is! AuthAuthenticated) {
      return;
    }

    final exercises = _exerciseEntries.asMap().entries.map((entry) {
      final e = entry.value;

      final sets = e.sets.map((s) {
        return WorkoutSetEntity(
          id: s.id,
          setNumber: s.setNumber,
          targetReps: s.reps,
          targetWeight: s.weight,
        );
      }).toList();

      return WorkoutExerciseEntity(
        id: e.id,
        exercise: e.exercise,
        sets: sets,
        orderIndex: entry.key,
      );
    }).toList();

    final workout = WorkoutEntity(
      id: _uuid.v4(),
      name: _nameCtrl.text.trim(),
      description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
      targetDays: _selectedDays,
      exercises: exercises,
      difficulty: _difficulty,
      estimatedDuration: _estimatedDuration,
      userId: authState.user.id,
      createdAt: DateTime.now(),
    );

    context.read<WorkoutBloc>().add(
          WorkoutCreated(workout),
        );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Workout created successfully'),
        backgroundColor: AppTheme.success,
      ),
    );

    Future.delayed(
      const Duration(milliseconds: 500),
      () {
        if (mounted) {
          context.go('/home');
        }
      },
    );
  }

  void _showExercisePicker() async {
    final selectedExercise = await showModalBottomSheet<ExerciseEntity>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(24),
        ),
      ),
      builder: (_) {
        return _ExercisePickerSheet(
          exercises: _availableExercises,
          loading: _loadingExercises,
        );
      },
    );

    if (selectedExercise != null) {
      _addExercise(selectedExercise);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Create Workout'),
        leading: IconButton(
          onPressed: () {
            context.go('/home');
          },
          icon: const Icon(Icons.close),
        ),
        actions: [
          TextButton(
            onPressed: _saveWorkout,
            child: const Text(
              'Save',
              style: TextStyle(
                color: AppTheme.primary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameCtrl,
              style: const TextStyle(
                color: AppTheme.textPrimary,
              ),
              decoration: const InputDecoration(
                labelText: 'Workout Name',
                hintText: 'Chest Day',
                prefixIcon: Icon(
                  Icons.edit_outlined,
                  color: AppTheme.textMuted,
                ),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) {
                  return 'Enter workout name';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _descCtrl,
              maxLines: 2,
              style: const TextStyle(
                color: AppTheme.textPrimary,
              ),
              decoration: const InputDecoration(
                labelText: 'Description',
                prefixIcon: Icon(
                  Icons.notes,
                  color: AppTheme.textMuted,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Difficulty',
              style: Theme.of(context).textTheme.labelLarge,
            ),
            const SizedBox(height: 12),
            Row(
              children: WorkoutDifficulty.values.map((d) {
                final isSelected = _difficulty == d;

                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _difficulty = d;
                      });
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                        right: 8,
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.primary.withOpacity(0.15)
                            : AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(
                          10,
                        ),
                        border: Border.all(
                          color: isSelected
                              ? AppTheme.primary
                              : const Color(0xFF1E2940),
                        ),
                      ),
                      child: Text(
                        d.name.toUpperCase(),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: isSelected
                              ? AppTheme.primary
                              : AppTheme.textSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            Text(
              'Training Days',
              style: Theme.of(context).textTheme.labelLarge,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: AppConstants.weekDays.map((day) {
                final selected = _selectedDays.contains(day);

                return GestureDetector(
                  onTap: () {
                    setState(() {
                      if (selected) {
                        _selectedDays.remove(day);
                      } else {
                        _selectedDays.add(day);
                      }
                    });
                  },
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: selected ? AppTheme.primary : AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(
                        10,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        day.substring(0, 3),
                        style: TextStyle(
                          color:
                              selected ? AppTheme.bgDark : AppTheme.textPrimary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Exercises',
                  style: Theme.of(context).textTheme.labelLarge,
                ),
                TextButton.icon(
                  onPressed: _showExercisePicker,
                  icon: const Icon(Icons.add),
                  label: const Text('Add'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_exerciseEntries.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Center(
                  child: Text(
                    'No exercises added',
                    style: TextStyle(
                      color: AppTheme.textMuted,
                    ),
                  ),
                ),
              )
            else
              ..._exerciseEntries.map(
                _buildExerciseEntry,
              ),
            const SizedBox(height: 24),
            GradientButton(
              label: 'Save Workout',
              icon: Icons.save_outlined,
              onPressed: _saveWorkout,
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildExerciseEntry(
    _ExerciseEntry entry,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  entry.exercise.name,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ),
              IconButton(
                onPressed: () => _removeExercise(entry.id),
                icon: const Icon(
                  Icons.delete_outline,
                  color: AppTheme.error,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...entry.sets.map(
            (set) => _buildSetInput(entry, set),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: () => _addSet(entry),
              icon: const Icon(Icons.add),
              label: const Text('Add Set'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSetInput(
    _ExerciseEntry entry,
    _SetEntry set,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Set ${set.setNumber}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppTheme.textPrimary,
              ),
            ),
          ),
          Expanded(
            child: TextFormField(
              initialValue: set.reps.toString(),
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              onChanged: (v) {
                set.reps = int.tryParse(v) ?? 0;
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              initialValue: set.weight.toString(),
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              onChanged: (v) {
                set.weight = int.tryParse(v) ?? 0;
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ExerciseEntry {
  final String id;
  final ExerciseEntity exercise;
  final List<_SetEntry> sets;

  _ExerciseEntry({
    required this.id,
    required this.exercise,
    required this.sets,
  });
}

class _SetEntry {
  final String id;
  final int setNumber;

  int reps;
  int weight;

  _SetEntry({
    required this.id,
    required this.setNumber,
    required this.reps,
    required this.weight,
  });
}

class _ExercisePickerSheet extends StatefulWidget {
  final List<ExerciseEntity> exercises;
  final bool loading;

  const _ExercisePickerSheet({
    required this.exercises,
    required this.loading,
  });

  @override
  State<_ExercisePickerSheet> createState() => _ExercisePickerSheetState();
}

class _ExercisePickerSheetState extends State<_ExercisePickerSheet> {
  String _query = '';

  List<ExerciseEntity> get _filteredExercises {
    return widget.exercises.where((exercise) {
      return exercise.name.toLowerCase().contains(_query.toLowerCase());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      builder: (_, controller) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.textMuted,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                onChanged: (v) {
                  setState(() {
                    _query = v;
                  });
                },
                decoration: const InputDecoration(
                  hintText: 'Search exercise',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: widget.loading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : _filteredExercises.isEmpty
                        ? const Center(
                            child: Text(
                              'No exercises found',
                            ),
                          )
                        : ListView.builder(
                            controller: controller,
                            itemCount: _filteredExercises.length,
                            itemBuilder: (_, index) {
                              final exercise = _filteredExercises[index];

                              return ListTile(
                                onTap: () {
                                  Navigator.pop(
                                    context,
                                    exercise,
                                  );
                                },
                                title: Text(
                                  exercise.name,
                                ),
                                subtitle: Text(
                                  '${exercise.muscleGroup} • ${exercise.equipment}',
                                ),
                                trailing: const Icon(
                                  Icons.add_circle_outline,
                                ),
                              );
                            },
                          ),
              ),
            ],
          ),
        );
      },
    );
  }
}
