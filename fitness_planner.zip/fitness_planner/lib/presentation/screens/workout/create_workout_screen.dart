import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/domain/entities/exercise_entity.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/entities/workout_exercise_entity.dart';
import 'package:fitness_planner/domain/entities/workout_set_entity.dart';
import 'package:fitness_planner/domain/repositories/exercise_repository.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';
import 'package:fitness_planner/core/di/injection_container.dart';
import 'package:fitness_planner/presentation/widgets/common/gradient_button.dart';
import 'package:uuid/uuid.dart';

class CreateWorkoutScreen extends StatefulWidget {
  const CreateWorkoutScreen({super.key});

  @override
  State<CreateWorkoutScreen> createState() => _CreateWorkoutScreenState();
}

class _CreateWorkoutScreenState extends State<CreateWorkoutScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _uuid = const Uuid();

  WorkoutDifficulty _difficulty = WorkoutDifficulty.beginner;
  final List<String> _selectedDays = [];
  final List<_ExerciseEntry> _exerciseEntries = [];
  int? _estimatedDuration;

  List<ExerciseEntity> _availableExercises = [];
  bool _loadingExercises = true;

  @override
  void initState() {
    super.initState();
    _loadExercises();
  }

  Future<void> _loadExercises() async {
    final result = await sl<ExerciseRepository>().getExercises();
    result.fold(
      (_) {},
      (exercises) => setState(() {
        _availableExercises = exercises;
        _loadingExercises = false;
      }),
    );
    if (_availableExercises.isEmpty) setState(() => _loadingExercises = false);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  void _addExercise(ExerciseEntity exercise) {
    setState(() {
      _exerciseEntries.add(_ExerciseEntry(
        id: _uuid.v4(),
        exercise: exercise,
        sets: [
          _SetEntry(id: _uuid.v4(), setNumber: 1, reps: 12, weight: 0),
        ],
      ));
    });
  }

  void _addSet(_ExerciseEntry entry) {
    setState(() {
      entry.sets.add(_SetEntry(
        id: _uuid.v4(),
        setNumber: entry.sets.length + 1,
        reps: entry.sets.last.reps,
        weight: entry.sets.last.weight,
      ));
    });
  }

  void _removeExercise(String entryId) {
    setState(() {
      _exerciseEntries.removeWhere((e) => e.id == entryId);
    });
  }

  void _saveWorkout() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_selectedDays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one day')),
      );
      return;
    }
    if (_exerciseEntries.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add at least one exercise')),
      );
      return;
    }

    final authState = context.read<AuthBloc>().state;
    if (authState is! AuthAuthenticated) return;

    final exercises = _exerciseEntries.asMap().entries.map((entry) {
      final e = entry.value;
      final sets = e.sets
          .map((s) => WorkoutSetEntity(
                id: s.id,
                setNumber: s.setNumber,
                targetReps: s.reps,
                targetWeight: s.weight,
              ))
          .toList();
      return WorkoutExerciseEntity(
        id: e.id,
        exercise: e.exercise,
        sets: sets,
        orderIndex: entry.key,
      );
    }).toList();

    final workout = WorkoutEntity(
      id: _uuid.v4(),
      name: _nameCtrl.text.trim(),
      description: _descCtrl.text.isEmpty ? null : _descCtrl.text.trim(),
      targetDays: _selectedDays,
      exercises: exercises,
      difficulty: _difficulty,
      estimatedDuration: _estimatedDuration,
      userId: authState.user.id,
      createdAt: DateTime.now(),
    );

    context.read<WorkoutBloc>().add(WorkoutCreated(workout));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ Workout created!'),
        backgroundColor: AppTheme.success,
      ),
    );
    context.pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Create Workout'),
        leading: IconButton(
          onPressed: () => context.pop(),
          icon: const Icon(Icons.close),
        ),
        actions: [
          TextButton(
            onPressed: _saveWorkout,
            child: const Text(
              'Save',
              style: TextStyle(
                  color: AppTheme.primary, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Name
            TextFormField(
              controller: _nameCtrl,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Workout Name',
                hintText: 'e.g., Chest Day, Leg Day',
                prefixIcon:
                    Icon(Icons.edit_outlined, color: AppTheme.textMuted),
              ),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Enter a workout name' : null,
            ),
            const SizedBox(height: 16),
            // Description
            TextFormField(
              controller: _descCtrl,
              style: const TextStyle(color: AppTheme.textPrimary),
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
                prefixIcon: Icon(Icons.notes, color: AppTheme.textMuted),
              ),
            ),
            const SizedBox(height: 24),

            // Difficulty
            Text('Difficulty', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 12),
            Row(
              children: WorkoutDifficulty.values.map((d) {
                final isSelected = _difficulty == d;
                final colors = {
                  WorkoutDifficulty.beginner: AppTheme.success,
                  WorkoutDifficulty.intermediate: AppTheme.warning,
                  WorkoutDifficulty.advanced: AppTheme.error,
                };
                final color = colors[d]!;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _difficulty = d),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? color.withOpacity(0.15)
                            : AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: isSelected ? color : const Color(0xFF1E2940),
                        ),
                      ),
                      child: Text(
                        d.name[0].toUpperCase() + d.name.substring(1),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: isSelected ? color : AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),

            // Days
            Text('Training Days',
                style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: AppConstants.weekDays.map((day) {
                final short = day.substring(0, 3);
                final isSelected = _selectedDays.contains(day);
                return GestureDetector(
                  onTap: () => setState(() {
                    isSelected
                        ? _selectedDays.remove(day)
                        : _selectedDays.add(day);
                  }),
                  child: Container(
                    width: 44,
                    height: 44,
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.primary : AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.primary
                            : const Color(0xFF1E2940),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        short,
                        style: TextStyle(
                          color: isSelected
                              ? AppTheme.bgDark
                              : AppTheme.textSecondary,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),

            // Exercises
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Exercises',
                    style: Theme.of(context).textTheme.labelLarge),
                TextButton.icon(
                  onPressed: () => _showExercisePicker(context),
                  icon:
                      const Icon(Icons.add, size: 18, color: AppTheme.primary),
                  label: const Text(
                    'Add',
                    style: TextStyle(color: AppTheme.primary),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            if (_exerciseEntries.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFF1E2940),
                    style: BorderStyle.solid,
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(
                      Icons.fitness_center_outlined,
                      color: AppTheme.textMuted,
                      size: 40,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'No exercises added yet',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              )
            else
              ..._exerciseEntries.map(
                (entry) => _buildExerciseEntry(entry),
              ),

            const SizedBox(height: 24),
            GradientButton(
              label: 'Save Workout',
              icon: Icons.save_outlined,
              onPressed: _saveWorkout,
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildExerciseEntry(_ExerciseEntry entry) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  entry.exercise.name,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ),
              IconButton(
                onPressed: () => _removeExercise(entry.id),
                icon: const Icon(Icons.delete_outline, color: AppTheme.error),
              ),
            ],
          ),
          Text(
            '${entry.exercise.muscleGroup} • ${entry.exercise.equipment}',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 12),
          // Sets
          const Row(
            children: [
              Expanded(
                  child: Text('Set',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(color: AppTheme.textMuted, fontSize: 12))),
              Expanded(
                  child: Text('Reps',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(color: AppTheme.textMuted, fontSize: 12))),
              Expanded(
                  child: Text('Weight(kg)',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(color: AppTheme.textMuted, fontSize: 12))),
            ],
          ),
          const SizedBox(height: 8),
          ...entry.sets.map((set) => _buildSetInput(entry, set)),
          TextButton.icon(
            onPressed: () => _addSet(entry),
            icon: const Icon(Icons.add, size: 16, color: AppTheme.primary),
            label: const Text(
              'Add Set',
              style: TextStyle(color: AppTheme.primary, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSetInput(_ExerciseEntry entry, _SetEntry set) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
            child: Center(
              child: Text(
                '${set.setNumber}',
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          Expanded(
            child: TextFormField(
              initialValue: set.reps.toString(),
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 8,
                ),
                filled: true,
                fillColor: AppTheme.bgCardLight,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (v) => set.reps = int.tryParse(v) ?? set.reps,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              initialValue: set.weight.toString(),
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 8,
                ),
                filled: true,
                fillColor: AppTheme.bgCardLight,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (v) => set.weight = int.tryParse(v) ?? set.weight,
            ),
          ),
        ],
      ),
    );
  }

  void _showExercisePicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _ExercisePickerSheet(
        exercises: _availableExercises,
        loading: _loadingExercises,
        onPick: (exercise) {
          _addExercise(exercise);
          Navigator.pop(context);
        },
      ),
    );
  }
}

class _ExerciseEntry {
  final String id;
  final ExerciseEntity exercise;
  final List<_SetEntry> sets;
  _ExerciseEntry({
    required this.id,
    required this.exercise,
    required this.sets,
  });
}

class _SetEntry {
  final String id;
  final int setNumber;
  int reps;
  int weight;
  _SetEntry({
    required this.id,
    required this.setNumber,
    required this.reps,
    required this.weight,
  });
}

class _ExercisePickerSheet extends StatefulWidget {
  final List<ExerciseEntity> exercises;
  final bool loading;
  final ValueChanged<ExerciseEntity> onPick;

  const _ExercisePickerSheet({
    required this.exercises,
    required this.loading,
    required this.onPick,
  });

  @override
  State<_ExercisePickerSheet> createState() => _ExercisePickerSheetState();
}

class _ExercisePickerSheetState extends State<_ExercisePickerSheet> {
  String _query = '';
  String? _selectedGroup;

  List<ExerciseEntity> get _filtered {
    return widget.exercises.where((e) {
      final matchQuery =
          _query.isEmpty || e.name.toLowerCase().contains(_query.toLowerCase());
      final matchGroup =
          _selectedGroup == null || e.muscleGroup == _selectedGroup;
      return matchQuery && matchGroup;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      builder: (_, controller) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.textMuted,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Add Exercise',
              style: Theme.of(context).textTheme.headlineLarge,
            ),
            const SizedBox(height: 12),
            // Search
            TextField(
              onChanged: (v) => setState(() => _query = v),
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                hintText: 'Search exercises...',
                prefixIcon: Icon(Icons.search, color: AppTheme.textMuted),
                isDense: true,
              ),
            ),
            const SizedBox(height: 12),
            // Group filter
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [null, ...AppConstants.muscleGroups].map((g) {
                  final isSelected = _selectedGroup == g;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedGroup = g),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.primary
                            : AppTheme.bgCardLight,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        g ?? 'All',
                        style: TextStyle(
                          color: isSelected
                              ? AppTheme.bgDark
                              : AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 12),
            // List
            Expanded(
              child: widget.loading
                  ? const Center(
                      child: CircularProgressIndicator(color: AppTheme.primary),
                    )
                  : _filtered.isEmpty
                      ? Center(
                          child: Text(
                            'No exercises found',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : ListView.builder(
                          controller: controller,
                          itemCount: _filtered.length,
                          itemBuilder: (_, i) {
                            final ex = _filtered[i];
                            return ListTile(
                              onTap: () => widget.onPick(ex),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 0,
                                vertical: 4,
                              ),
                              leading: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: AppTheme.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(
                                  Icons.fitness_center,
                                  color: AppTheme.primary,
                                  size: 20,
                                ),
                              ),
                              title: Text(
                                ex.name,
                                style: const TextStyle(
                                    color: AppTheme.textPrimary),
                              ),
                              subtitle: Text(
                                '${ex.muscleGroup} • ${ex.equipment}',
                                style: const TextStyle(
                                    color: AppTheme.textSecondary),
                              ),
                              trailing: const Icon(
                                Icons.add_circle_outline,
                                color: AppTheme.primary,
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
