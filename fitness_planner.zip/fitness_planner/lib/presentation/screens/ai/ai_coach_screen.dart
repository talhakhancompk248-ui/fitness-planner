import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/presentation/blocs/ai/ai_bloc.dart';
import 'package:fitness_planner/domain/entities/chat_message_entity.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/presentation/blocs/workout/workout_bloc.dart';
import 'package:fitness_planner/presentation/widgets/ai/ai_response_card.dart';
import 'package:fitness_planner/presentation/widgets/common/gradient_button.dart';

class AiCoachScreen extends StatefulWidget {
  const AiCoachScreen({super.key});
  @override
  State<AiCoachScreen> createState() => _AiCoachScreenState();
}

class _AiCoachScreenState extends State<AiCoachScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _chatController = TextEditingController();
  int _selectedDays = 3;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    // Add listener so the UI (like the AppBar) rebuilds when the tab index changes via swiping
    _tabController.addListener(() => setState(() {}));
    final currentUser = _user;
    if (currentUser?.id != null) {
      context.read<AiBloc>().add(AiLoadChatHistory(currentUser!.id));
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  UserEntity? get _user {
    // Use context.read instead of context.watch to avoid InheritedWidget errors in initState
    final state = context.read<AuthBloc>().state;
    return state is AuthAuthenticated ? state.user : null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppTheme.primary, AppTheme.secondary],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.psychology,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            const Text('AI Coach'),
            if (_tabController.index == 4)
              IconButton(
                icon: const Icon(Icons.delete_sweep, color: AppTheme.textMuted),
                onPressed: () => _confirmClearChatHistory(context),
              ),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primary,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.textMuted,
          tabs: [
            Tab(text: 'Plan'),
            Tab(text: 'Improve'),
            Tab(text: 'Tips'),
            Tab(text: 'Diet'),
            Tab(text: 'Chat'),
          ],
          onTap: (_) => setState(() {}),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildPlanTab(),
          _buildImprovementTab(),
          _buildTipsTab(),
          _buildDietTab(),
          _buildChatTab(),
        ],
      ),
    );
  }

  Widget _buildPlanTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
            'Generate Workout Plan',
            'Get a personalized weekly plan based on your goal',
            Icons.calendar_month,
          ),
          const SizedBox(height: 20),
          _buildDaysSelector(),
          const SizedBox(height: 20),
          GradientButton(
            label: 'Generate My Plan',
            icon: Icons.auto_awesome,
            onPressed: () {
              final user = _user;
              if (user != null) {
                context.read<AiBloc>().add(
                      AiGeneratePlanRequested(user, _selectedDays),
                    );
              }
            },
          ),
          const SizedBox(height: 20),
          BlocBuilder<AiBloc, AiState>(
            builder: (context, state) {
              if (state is AiLoading && state.feature == 'plan') {
                return _buildLoadingCard(
                    'Generating your personalized plan...');
              }
              if (state is AiError) {
                return _buildErrorCard(
                    'Failed to generate plan: ${state.message}');
              }
              if (state is AiPlanGenerated) {
                return AiResponseCard(
                  title: '🏋️ Your Workout Plan',
                  content: state.plan,
                  accentColor: AppTheme.primary,
                );
              }
              return _buildPlaceholder(
                  'Your personalized workout plan will appear here.');
            },
          ),
        ],
      ),
    );
  }

  Widget _buildImprovementTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
            'Improvement Suggestions',
            'AI analyzes your recent workouts and gives targeted advice',
            Icons.trending_up,
          ),
          const SizedBox(height: 20),
          GradientButton(
            label: 'Analyze My Workouts',
            icon: Icons.search,
            gradientColors: [AppTheme.secondary, const Color(0xFFFF8C61)],
            onPressed: () {
              final user = _user;
              final workoutState = context.read<WorkoutBloc>().state;
              if (user == null) return;
              if (workoutState is! WorkoutSuccess) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Wait for workouts to load...')));
              } else {
                context.read<AiBloc>().add(
                      AiImprovementsRequested(user, workoutState.workouts),
                    );
              }
            },
          ),
          const SizedBox(height: 20),
          BlocBuilder<AiBloc, AiState>(
            builder: (context, state) {
              if (state is AiLoading && state.feature == 'improvements') {
                return _buildLoadingCard('Analyzing your progress...');
              }
              if (state is AiError) {
                return _buildErrorCard(
                    'Failed to analyze workouts: ${state.message}');
              }
              if (state is AiImprovementsLoaded) {
                return AiResponseCard(
                  title: '📈 Improvement Suggestions',
                  content: state.suggestions,
                  accentColor: AppTheme.secondary,
                );
              }
              return _buildPlaceholder(
                  'Analyze your history for AI suggestions.');
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTipsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
            'Daily Fitness Tips',
            'Personalized advice to keep you on track',
            Icons.lightbulb_outline,
          ),
          const SizedBox(height: 20),
          GradientButton(
            label: 'Get Today\'s Tip',
            icon: Icons.tips_and_updates,
            gradientColors: [AppTheme.accent, const Color(0xFFFFB347)],
            onPressed: () {
              final user = _user;
              if (user != null) {
                context.read<AiBloc>().add(AiDailyTipRequested(user));
              }
            },
          ),
          const SizedBox(height: 20),
          BlocBuilder<AiBloc, AiState>(
            builder: (context, state) {
              if (state is AiLoading && state.feature == 'tip') {
                return _buildLoadingCard('Getting your daily tip...');
              }
              if (state is AiError) {
                return _buildErrorCard('Failed to get tip: ${state.message}');
              }
              if (state is AiTipLoaded) {
                return AiResponseCard(
                  title: '💡 Today\'s Tip',
                  content: state.tip,
                  accentColor: AppTheme.accent,
                );
              }
              return _buildPlaceholder('Tap the button for today\'s tip.');
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDietTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
            'Diet Suggestions',
            'Meal ideas tailored to your fitness goal',
            Icons.restaurant_menu,
          ),
          const SizedBox(height: 20),
          GradientButton(
            label: 'Get Diet Plan',
            icon: Icons.local_dining,
            gradientColors: [AppTheme.success, const Color(0xFF34D399)],
            onPressed: () {
              final user = _user;
              if (user != null) {
                context.read<AiBloc>().add(AiDietRequested(user));
              }
            },
          ),
          const SizedBox(height: 20),
          BlocBuilder<AiBloc, AiState>(
            builder: (context, state) {
              if (state is AiLoading && state.feature == 'diet') {
                return _buildLoadingCard('Creating your meal plan...');
              }
              if (state is AiError) {
                return _buildErrorCard(
                    'Failed to create meal plan: ${state.message}');
              }
              if (state is AiDietLoaded) {
                return AiResponseCard(
                  title: '🥗 Your Diet Plan',
                  content: state.diet,
                  accentColor: AppTheme.success,
                );
              }
              return _buildPlaceholder('Get your personalized diet plan.');
            },
          ),
        ],
      ),
    );
  }

  Widget _buildChatTab() {
    return Column(
      children: [
        Expanded(
          child: BlocBuilder<AiBloc, AiState>(
            builder: (context, state) {
              List<ChatMessageEntity> messages = [];
              if (state is AiChatHistoryLoaded) messages = state.messages;

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: messages.length + 1,
                itemBuilder: (context, index) {
                  if (index == 0)
                    return _buildSectionHeader(
                        'Chat', 'Ask the coach anything', Icons.chat);
                  return _buildChatMessage(messages[index - 1]);
                },
              );
            },
          ),
        ),
        _buildChatInput(),
      ],
    );
  }

  Widget _buildChatInput() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(child: TextField(controller: _chatController)),
          IconButton(icon: const Icon(Icons.send), onPressed: _sendChatMessage),
        ],
      ),
    );
  }

  void _sendChatMessage() {
    if (_chatController.text.isEmpty || _user == null) return;
    context.read<AiBloc>().add(AiSendMessage(_user!, _chatController.text));
    _chatController.clear();
  }

  void _confirmClearChatHistory(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Chat?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              if (_user?.id != null)
                context.read<AiBloc>().add(AiClearChatHistory(_user!.id));
              Navigator.pop(context);
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder(String message) {
    return Center(
        child: Text(message, style: TextStyle(color: AppTheme.textMuted)));
  }

  Widget _buildChatMessage(ChatMessageEntity msg) {
    final isUser = msg.sender == MessageSender.user;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isUser ? AppTheme.primary : AppTheme.bgCard,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(msg.content),
      ),
    );
  }

  Widget _buildSectionHeader(String title, String subtitle, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppTheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: AppTheme.primary, size: 24),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineSmall),
              Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDaysSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Available Days Per Week: $_selectedDays',
          style: Theme.of(context).textTheme.labelLarge,
        ),
        const SizedBox(height: 8),
        Slider(
          value: _selectedDays.toDouble(),
          min: 1,
          max: 7,
          divisions: 6,
          activeColor: AppTheme.primary,
          inactiveColor: AppTheme.bgCardLight,
          label: _selectedDays.toString(),
          onChanged: (v) => setState(() => _selectedDays = v.round()),
        ),
      ],
    );
  }

  Widget _buildLoadingCard(String message) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        // Use withOpacity for better compatibility with SDK 3.0.0
        border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: AppTheme.primary,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(message, style: Theme.of(context).textTheme.bodyLarge),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorCard(String message) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.red),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.red[300],
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
