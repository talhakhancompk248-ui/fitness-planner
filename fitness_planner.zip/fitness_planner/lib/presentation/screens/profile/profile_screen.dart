import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/repositories/user_repository.dart';
import 'package:fitness_planner/presentation/blocs/auth/auth_bloc.dart';
import 'package:fitness_planner/core/di/injection_container.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isEditing = false;
  bool _isSaving = false;
  late TextEditingController _nameCtrl;
  late TextEditingController _heightCtrl;
  late TextEditingController _weightCtrl;
  late TextEditingController _ageCtrl;
  String _fitnessGoal = AppConstants.goalMaintain;
  String _fitnessLevel = AppConstants.diffBeginner;

  @override
  void initState() {
    super.initState();
    final state = context.read<AuthBloc>().state;
    final user = state is AuthAuthenticated ? state.user : null;
    _nameCtrl = TextEditingController(text: user?.name ?? '');
    _heightCtrl = TextEditingController(text: user?.height?.toString() ?? '');
    _weightCtrl = TextEditingController(text: user?.weight?.toString() ?? '');
    _ageCtrl = TextEditingController(text: user?.age?.toString() ?? '');
    _fitnessGoal = user?.fitnessGoal ?? AppConstants.goalMaintain;
    _fitnessLevel = user?.fitnessLevel ?? AppConstants.diffBeginner;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _heightCtrl.dispose();
    _weightCtrl.dispose();
    _ageCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveProfile(UserEntity user) async {
    if (!mounted) return;

    setState(() => _isSaving = true);
    final updated = user.copyWith(
      name: _nameCtrl.text.trim(),
      height: double.tryParse(_heightCtrl.text),
      weight: double.tryParse(_weightCtrl.text),
      age: int.tryParse(_ageCtrl.text),
      fitnessGoal: _fitnessGoal,
      fitnessLevel: _fitnessLevel,
    );

    try {
      final result = await sl<UserRepository>().updateUserProfile(updated);

      if (!mounted) return;

      result.fold(
        (failure) {
          // Error case
          setState(() {
            _isSaving = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to update profile: ${failure.message}'),
              backgroundColor: AppTheme.error,
            ),
          );
        },
        (_) {
          // Success case
          setState(() {
            _isSaving = false;
            _isEditing = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profile updated!'),
              backgroundColor: AppTheme.success,
            ),
          );
        },
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSaving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: AppTheme.error,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, state) {
        if (state is! AuthAuthenticated) return const SizedBox.shrink();
        final user = state.user;

        return Scaffold(
          backgroundColor: AppTheme.bgDark,
          appBar: AppBar(
            title: const Text('Profile'),
            actions: [
              if (_isEditing)
                TextButton(
                  onPressed: _isSaving ? null : () => _saveProfile(user),
                  child: _isSaving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: AppTheme.primary,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'Save',
                          style: TextStyle(
                            color: AppTheme.primary,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                )
              else
                IconButton(
                  onPressed: () => setState(() => _isEditing = true),
                  icon:
                      const Icon(Icons.edit_outlined, color: AppTheme.primary),
                ),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Avatar
                Center(
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: AppTheme.primary.withOpacity(0.2),
                        child: Text(
                          user.name.isNotEmpty
                              ? user.name[0].toUpperCase()
                              : '?',
                          style: const TextStyle(
                            color: AppTheme.primary,
                            fontSize: 36,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                if (!_isEditing) ...[
                  Text(
                    user.name,
                    style: Theme.of(context).textTheme.displaySmall,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user.email,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
                const SizedBox(height: 24),

                // BMI Card
                if (user.bmi != null) _buildBmiCard(context, user),

                const SizedBox(height: 24),

                // Stats / Edit Form
                _isEditing
                    ? _buildEditForm(context)
                    : _buildStatsView(context, user),

                const SizedBox(height: 24),

                // Goal Card
                _buildGoalCard(context, user),

                const SizedBox(height: 24),

                // Sign Out
                OutlinedButton.icon(
                  onPressed: () {
                    context.read<AuthBloc>().add(AuthSignOutRequested());
                  },
                  icon: const Icon(Icons.logout, color: AppTheme.error),
                  label: const Text(
                    'Sign Out',
                    style: TextStyle(color: AppTheme.error),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppTheme.error),
                    minimumSize: const Size(double.infinity, 48),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBmiCard(BuildContext context, UserEntity user) {
    final bmi = user.bmi!;
    final Color bmiColor;
    if (bmi < 18.5) {
      bmiColor = AppTheme.info;
    } else if (bmi < 25)
      bmiColor = AppTheme.success;
    else if (bmi < 30)
      bmiColor = AppTheme.warning;
    else
      bmiColor = AppTheme.error;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [bmiColor.withOpacity(0.2), bmiColor.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: bmiColor.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'BMI',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
              Text(
                bmi.toStringAsFixed(1),
                style: TextStyle(
                  color: bmiColor,
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                user.bmiCategory,
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(color: bmiColor),
              ),
              const SizedBox(height: 4),
              Text(
                'Based on your height & weight',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatsView(BuildContext context, UserEntity user) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Column(
        children: [
          _statRow(context, 'Height', '${user.height ?? '—'} cm', Icons.height),
          _divider(),
          _statRow(context, 'Weight', '${user.weight ?? '—'} kg',
              Icons.monitor_weight_outlined),
          _divider(),
          _statRow(
              context, 'Age', '${user.age ?? '—'} years', Icons.cake_outlined),
          _divider(),
          _statRow(context, 'Gender', user.gender ?? '—', Icons.person_outline),
          _divider(),
          _statRow(context, 'Weekly Days',
              '${user.weeklyWorkoutDays ?? '—'} days', Icons.calendar_today),
        ],
      ),
    );
  }

  Widget _buildEditForm(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E2940)),
      ),
      child: Column(
        children: [
          TextField(
            controller: _nameCtrl,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(
              labelText: 'Full Name',
              prefixIcon: Icon(Icons.person_outline, color: AppTheme.textMuted),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _heightCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: AppTheme.textPrimary),
                  decoration: const InputDecoration(
                    labelText: 'Height (cm)',
                    prefixIcon: Icon(Icons.height, color: AppTheme.textMuted),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _weightCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: AppTheme.textPrimary),
                  decoration: const InputDecoration(
                    labelText: 'Weight (kg)',
                    prefixIcon: Icon(
                      Icons.monitor_weight_outlined,
                      color: AppTheme.textMuted,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _ageCtrl,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(
              labelText: 'Age',
              prefixIcon: Icon(Icons.cake_outlined, color: AppTheme.textMuted),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            initialValue: _fitnessGoal,
            dropdownColor: AppTheme.bgCard,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(labelText: 'Fitness Goal'),
            items: [
              AppConstants.goalLoseWeight,
              AppConstants.goalGainMuscle,
              AppConstants.goalMaintain,
            ].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
            onChanged: (v) => setState(() => _fitnessGoal = v!),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _fitnessLevel,
            dropdownColor: AppTheme.bgCard,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(labelText: 'Fitness Level'),
            items: [
              AppConstants.diffBeginner,
              AppConstants.diffIntermediate,
              AppConstants.diffAdvanced,
            ].map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
            onChanged: (v) => setState(() => _fitnessLevel = v!),
          ),
        ],
      ),
    );
  }

  Widget _buildGoalCard(BuildContext context, UserEntity user) {
    final goalIcons = {
      AppConstants.goalLoseWeight: '🔥',
      AppConstants.goalGainMuscle: '💪',
      AppConstants.goalMaintain: '⚖️',
    };

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Text(
            goalIcons[user.fitnessGoal] ?? '🎯',
            style: const TextStyle(fontSize: 32),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Current Goal',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
              Text(
                user.fitnessGoal,
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(color: AppTheme.primary),
              ),
              Text(
                user.fitnessLevel ?? 'Beginner',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statRow(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.primary, size: 20),
          const SizedBox(width: 12),
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          const Spacer(),
          Text(
            value,
            style: Theme.of(context).textTheme.labelLarge,
          ),
        ],
      ),
    );
  }

  Widget _divider() => const Divider(color: Color(0xFF1E2940), height: 1);
}
