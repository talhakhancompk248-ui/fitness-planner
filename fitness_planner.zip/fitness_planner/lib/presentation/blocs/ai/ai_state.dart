part of 'ai_bloc.dart';

abstract class AiState extends Equatable {
  const AiState();
  @override
  List<Object?> get props => [];
}

class AiInitial extends AiState {}

class AiLoading extends AiState {
  final String feature;
  const AiLoading({required this.feature});
  @override
  List<Object> get props => [feature];
}

class AiPlanGenerated extends AiState {
  final String plan;
  const AiPlanGenerated(this.plan);
  @override
  List<Object> get props => [plan];
}

class AiImprovementsLoaded extends AiState {
  final String suggestions;
  const AiImprovementsLoaded(this.suggestions);
  @override
  List<Object> get props => [suggestions];
}

class AiTipLoaded extends AiState {
  final String tip;
  const AiTipLoaded(this.tip);
  @override
  List<Object> get props => [tip];
}

class AiDietLoaded extends AiState {
  final String diet;
  const AiDietLoaded(this.diet);
  @override
  List<Object> get props => [diet];
}

class AiError extends AiState {
  final String message;
  const AiError(this.message);
  @override
  List<Object> get props => [message];
}

class AiChatHistoryLoaded extends AiState {
  final List<ChatMessageEntity> messages;
  const AiChatHistoryLoaded(this.messages);
  @override
  List<Object> get props => [messages];
}
