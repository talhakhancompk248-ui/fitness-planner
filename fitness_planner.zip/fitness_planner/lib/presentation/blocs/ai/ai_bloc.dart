import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/entities/chat_message_entity.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';
import 'package:fitness_planner/domain/usecases/ai/generate_workout_plan_usecase.dart';
import 'package:fitness_planner/domain/usecases/ai/get_daily_tip_usecase.dart';
import 'package:fitness_planner/domain/usecases/ai/get_improvement_suggestions_usecase.dart';

part 'ai_event.dart';
part 'ai_state.dart';

class AiBloc extends Bloc<AiEvent, AiState> {
  final GenerateWorkoutPlanUseCase generateWorkoutPlanUseCase;
  final GetImprovementSuggestionsUseCase getImprovementSuggestionsUseCase;
  final GetDailyTipUseCase getDailyTipUseCase;
  final AiRepository aiRepository;
  final _uuid = const Uuid();

  AiBloc({
    required this.generateWorkoutPlanUseCase,
    required this.getImprovementSuggestionsUseCase,
    required this.getDailyTipUseCase,
    required this.aiRepository,
  }) : super(AiInitial()) {
    on<AiGeneratePlanRequested>(_onGeneratePlan);
    on<AiImprovementsRequested>(_onImprovements);
    on<AiDailyTipRequested>(_onDailyTip);
    on<AiDietRequested>(_onDiet);
    on<AiSendMessage>(_onSendMessage);
    on<AiLoadChatHistory>(_onLoadChatHistory);
    on<AiDeleteChatMessage>(_onDeleteChatMessage);
    on<AiClearChatHistory>(_onClearChatHistory);
  }

  Future<void> _onGeneratePlan(
    AiGeneratePlanRequested event,
    Emitter<AiState> emit,
  ) async {
    emit(AiLoading(feature: 'plan'));
    final result = await generateWorkoutPlanUseCase(event.user, event.days);
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (plan) => emit(AiPlanGenerated(plan)),
    );
  }

  Future<void> _onImprovements(
    AiImprovementsRequested event,
    Emitter<AiState> emit,
  ) async {
    emit(AiLoading(feature: 'improvements'));
    final result = await getImprovementSuggestionsUseCase(
      event.user,
      event.workouts,
    );
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (suggestions) => emit(AiImprovementsLoaded(suggestions)),
    );
  }

  Future<void> _onDailyTip(
    AiDailyTipRequested event,
    Emitter<AiState> emit,
  ) async {
    emit(AiLoading(feature: 'tip'));
    final result = await getDailyTipUseCase(event.user);
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (tip) => emit(AiTipLoaded(tip)),
    );
  }

  Future<void> _onDiet(
    AiDietRequested event,
    Emitter<AiState> emit,
  ) async {
    emit(AiLoading(feature: 'diet'));
    final result = await aiRepository.getDietSuggestions(user: event.user);
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (diet) => emit(AiDietLoaded(diet)),
    );
  }

  Future<void> _onSendMessage(
    AiSendMessage event,
    Emitter<AiState> emit,
  ) async {
    // 1. Save user message
    final userMsg = ChatMessageEntity(
      id: _uuid.v4(),
      userId: event.user.id,
      sender: MessageSender.user,
      content: event.message,
      timestamp: DateTime.now(),
    );

    await aiRepository.saveChatMessage(userMsg);

    // Get current history to show user message immediately if possible,
    // or just trigger reload.
    add(AiLoadChatHistory(event.user.id));

    // 2. Get AI response and save it
    // Note: We don't emit AiLoading for the whole state if we want to keep the user message visible
    emit(const AiLoading(feature: 'chat'));
    final result = await aiRepository.chatWithAi(event.user, event.message);

    await result.fold(
      (failure) async => emit(AiError(failure.message)),
      (response) async {
        final aiMsg = ChatMessageEntity(
          id: _uuid.v4(),
          userId: event.user.id,
          sender: MessageSender.ai,
          content: response,
          timestamp: DateTime.now(),
        );
        final saveAiResult = await aiRepository.saveChatMessage(aiMsg);
        if (saveAiResult.isSuccess) add(AiLoadChatHistory(event.user.id));
      },
    );
  }

  Future<void> _onLoadChatHistory(
    AiLoadChatHistory event,
    Emitter<AiState> emit,
  ) async {
    final result = await aiRepository.getChatHistory(event.userId);
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (messages) => emit(AiChatHistoryLoaded(messages)),
    );
  }

  Future<void> _onDeleteChatMessage(
    AiDeleteChatMessage event,
    Emitter<AiState> emit,
  ) async {
    emit(const AiLoading(feature: 'chat_delete'));
    final result = await aiRepository.deleteChatMessage(event.messageId);
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (_) =>
          add(AiLoadChatHistory(event.userId)), // Reload history after deletion
    );
  }

  Future<void> _onClearChatHistory(
    AiClearChatHistory event,
    Emitter<AiState> emit,
  ) async {
    emit(const AiLoading(feature: 'chat_clear'));
    final result = await aiRepository.clearChatHistory(event.userId);
    result.fold(
      (failure) => emit(AiError(failure.message)),
      (_) =>
          add(AiLoadChatHistory(event.userId)), // Reload history after clearing
    );
  }
}
