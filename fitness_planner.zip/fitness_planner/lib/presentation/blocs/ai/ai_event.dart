part of 'ai_bloc.dart';

abstract class AiEvent extends Equatable {
  const AiEvent();
  @override
  List<Object?> get props => [];
}

class AiGeneratePlanRequested extends AiEvent {
  final UserEntity user;
  final int days;
  const AiGeneratePlanRequested(this.user, this.days);
  @override
  List<Object> get props => [user, days];
}

class AiImprovementsRequested extends AiEvent {
  final UserEntity user;
  final List<WorkoutEntity> workouts;
  const AiImprovementsRequested(this.user, this.workouts);
  @override
  List<Object> get props => [user, workouts];
}

class AiDailyTipRequested extends AiEvent {
  final UserEntity user;
  const AiDailyTipRequested(this.user);
  @override
  List<Object> get props => [user];
}

class AiDietRequested extends AiEvent {
  final UserEntity user;
  const AiDietRequested(this.user);
  @override
  List<Object> get props => [user];
}

class AiSendMessage extends AiEvent {
  final UserEntity user;
  final String message;
  const AiSendMessage(this.user, this.message);
  @override
  List<Object> get props => [user, message];
}

class AiLoadChatHistory extends AiEvent {
  final String userId;
  const AiLoadChatHistory(this.userId);
  @override
  List<Object> get props => [userId];
}

class AiDeleteChatMessage extends AiEvent {
  final String messageId;
  final String userId;
  const AiDeleteChatMessage(this.messageId, this.userId);
  @override
  List<Object> get props => [messageId, userId];
}

class AiClearChatHistory extends AiEvent {
  final String userId;
  const AiClearChatHistory(this.userId);
  @override
  List<Object> get props => [userId];
}
