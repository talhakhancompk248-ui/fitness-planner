import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/workout_repository.dart';
import 'package:fitness_planner/domain/usecases/workout/complete_workout_usecase.dart';
import 'package:fitness_planner/domain/usecases/workout/create_workout_usecase.dart';
import 'package:fitness_planner/domain/usecases/workout/get_workouts_by_day_usecase.dart';

part 'workout_event.dart';
part 'workout_state.dart';

class WorkoutBloc extends Bloc<WorkoutEvent, WorkoutState> {
  final WorkoutRepository workoutRepository;
  final CreateWorkoutUseCase createWorkoutUseCase;
  final CompleteWorkoutUseCase completeWorkoutUseCase;
  final GetWorkoutsByDayUseCase getWorkoutsByDayUseCase;
  StreamSubscription? _workoutSub;

  WorkoutBloc({
    required this.workoutRepository,
    required this.createWorkoutUseCase,
    required this.completeWorkoutUseCase,
    required this.getWorkoutsByDayUseCase,
  }) : super(WorkoutInitial()) {
    on<WorkoutSubscribed>(_onSubscribed);
    on<WorkoutLoaded>(_onLoaded);
    on<WorkoutCreated>(_onCreated);
    on<WorkoutCompleted>(_onCompleted);
    on<WorkoutUpdated>(_onUpdated);
    on<WorkoutDeleted>(_onDeleted);
  }

  void _onSubscribed(WorkoutSubscribed event, Emitter<WorkoutState> emit) {
    _workoutSub?.cancel();
    emit(WorkoutLoading());
    _workoutSub = workoutRepository.watchUserWorkouts(event.userId).listen(
          (workouts) => add(WorkoutLoaded(workouts)),
          onError: (e) => emit(WorkoutError(e.toString())),
        );
  }

  void _onLoaded(WorkoutLoaded event, Emitter<WorkoutState> emit) {
    emit(WorkoutSuccess(workouts: event.workouts));
  }

  Future<void> _onCreated(
    WorkoutCreated event,
    Emitter<WorkoutState> emit,
  ) async {
    final current = state;
    final result = await createWorkoutUseCase(event.workout);
    result.fold(
      (failure) => emit(WorkoutError(failure.message)),
      (workout) {
        if (current is WorkoutSuccess) {
          emit(WorkoutSuccess(workouts: [workout, ...current.workouts]));
        } else {
          // If not in success state, still emit success with the new workout
          emit(WorkoutSuccess(workouts: [workout]));
        }
      },
    );
  }

  Future<void> _onCompleted(
    WorkoutCompleted event,
    Emitter<WorkoutState> emit,
  ) async {
    final result = await completeWorkoutUseCase(event.workout);
    result.fold(
      (failure) => emit(WorkoutError(failure.message)),
      (_) {
        // Success is handled by the stream subscription
      },
    );
  }

  Future<void> _onUpdated(
    WorkoutUpdated event,
    Emitter<WorkoutState> emit,
  ) async {
    try {
      final result = await workoutRepository.updateWorkout(event.workout);
      result.fold(
        (failure) => emit(WorkoutError(failure.message)),
        (_) {
          // Update is handled by stream subscription
        },
      );
    } catch (e) {
      emit(WorkoutError(e.toString()));
    }
  }

  Future<void> _onDeleted(
    WorkoutDeleted event,
    Emitter<WorkoutState> emit,
  ) async {
    try {
      final result = await workoutRepository.deleteWorkout(event.workoutId);
      result.fold(
        (failure) => emit(WorkoutError(failure.message)),
        (_) {
          // Deletion is handled by stream subscription
        },
      );
    } catch (e) {
      emit(WorkoutError(e.toString()));
    }
  }

  @override
  Future<void> close() {
    _workoutSub?.cancel();
    return super.close();
  }
}
