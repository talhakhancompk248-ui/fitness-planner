part of 'workout_bloc.dart';

abstract class WorkoutState extends Equatable {
  const WorkoutState();
  @override
  List<Object?> get props => [];
}

class WorkoutInitial extends WorkoutState {}

class WorkoutLoading extends WorkoutState {}

class WorkoutSuccess extends WorkoutState {
  final List<WorkoutEntity> workouts;
  const WorkoutSuccess({required this.workouts});
  @override
  List<Object> get props => [workouts];
}

class WorkoutError extends WorkoutState {
  final String message;
  const WorkoutError(this.message);
  @override
  List<Object> get props => [message];
}
