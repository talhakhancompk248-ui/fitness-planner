part of 'workout_bloc.dart';

abstract class WorkoutEvent extends Equatable {
  const WorkoutEvent();
  @override
  List<Object?> get props => [];
}

class WorkoutSubscribed extends WorkoutEvent {
  final String userId;
  const WorkoutSubscribed(this.userId);
  @override
  List<Object> get props => [userId];
}

class WorkoutLoaded extends WorkoutEvent {
  final List<WorkoutEntity> workouts;
  const WorkoutLoaded(this.workouts);
  @override
  List<Object> get props => [workouts];
}

class WorkoutCreated extends WorkoutEvent {
  final WorkoutEntity workout;
  const WorkoutCreated(this.workout);
  @override
  List<Object> get props => [workout];
}

class WorkoutCompleted extends WorkoutEvent {
  final WorkoutEntity workout;
  const WorkoutCompleted(this.workout);
  @override
  List<Object> get props => [workout];
}

class WorkoutUpdated extends WorkoutEvent {
  final WorkoutEntity workout;
  const WorkoutUpdated(this.workout);
  @override
  List<Object> get props => [workout];
}

class WorkoutDeleted extends WorkoutEvent {
  final String workoutId;
  const WorkoutDeleted(this.workoutId);
  @override
  List<Object> get props => [workoutId];
}
