part of 'progress_bloc.dart';

abstract class ProgressEvent extends Equatable {
  const ProgressEvent();
  @override
  List<Object?> get props => [];
}

// Fired to start listening to Firestore stream
class ProgressSubscribed extends ProgressEvent {
  final String userId;
  const ProgressSubscribed(this.userId);
  @override
  List<Object> get props => [userId];
}

// Fired internally when stream emits new data
class _ProgressStreamUpdated extends ProgressEvent {
  final List<ProgressEntryEntity> entries;
  const _ProgressStreamUpdated(this.entries);
  @override
  List<Object> get props => [entries];
}

// Fired by UI to log a new measurement
class ProgressEntryAdded extends ProgressEvent {
  final String userId;
  final double? weight;
  final double? waistCm;
  final String? notes;
  const ProgressEntryAdded({
    required this.userId,
    this.weight,
    this.waistCm,
    this.notes,
  });
  @override
  List<Object?> get props => [userId, weight, waistCm, notes];
}

// Fired by UI to delete an entry
class ProgressEntryDeleted extends ProgressEvent {
  final String entryId;
  const ProgressEntryDeleted(this.entryId);
  @override
  List<Object> get props => [entryId];
}
