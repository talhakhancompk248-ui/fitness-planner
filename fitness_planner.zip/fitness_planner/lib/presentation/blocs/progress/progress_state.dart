part of 'progress_bloc.dart';

abstract class ProgressState extends Equatable {
  const ProgressState();
  @override
  List<Object?> get props => [];
}

class ProgressInitial extends ProgressState {}

class ProgressLoading extends ProgressState {}

class ProgressLoaded extends ProgressState {
  final List<ProgressEntryEntity> entries;
  const ProgressLoaded(this.entries);
  @override
  List<Object> get props => [entries];
}

class ProgressError extends ProgressState {
  final String message;
  const ProgressError(this.message);
  @override
  List<Object> get props => [message];
}
