import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fitness_planner/domain/entities/progress_entry_entity.dart';
import 'package:fitness_planner/domain/repositories/progress_repository.dart';
import 'package:fitness_planner/domain/usecases/progress/add_progress_entry_usecase.dart';
import 'package:uuid/uuid.dart';

part 'progress_event.dart';
part 'progress_state.dart';

class ProgressBloc extends Bloc<ProgressEvent, ProgressState> {
  final ProgressRepository progressRepository;
  final AddProgressEntryUseCase addProgressEntryUseCase;
  StreamSubscription<List<ProgressEntryEntity>>? _progressSub;
  final _uuid = const Uuid();

  ProgressBloc({
    required this.progressRepository,
    required this.addProgressEntryUseCase,
  }) : super(ProgressInitial()) {
    on<ProgressSubscribed>(_onSubscribed);
    on<_ProgressStreamUpdated>(_onStreamUpdated);
    on<ProgressEntryAdded>(_onEntryAdded);
    on<ProgressEntryDeleted>(_onEntryDeleted);
  }

  void _onSubscribed(
    ProgressSubscribed event,
    Emitter<ProgressState> emit,
  ) {
    _progressSub?.cancel();
    emit(ProgressLoading());
    _progressSub = progressRepository.watchProgress(event.userId).listen(
          (entries) => add(_ProgressStreamUpdated(entries)),
          onError: (e) => emit(ProgressError(e.toString())),
        );
  }

  void _onStreamUpdated(
    _ProgressStreamUpdated event,
    Emitter<ProgressState> emit,
  ) {
    emit(ProgressLoaded(event.entries));
  }

  Future<void> _onEntryAdded(
    ProgressEntryAdded event,
    Emitter<ProgressState> emit,
  ) async {
    final entry = ProgressEntryEntity(
      id: _uuid.v4(),
      userId: event.userId,
      date: DateTime.now(),
      weight: event.weight,
      waistCm: event.waistCm,
      notes: event.notes,
    );

    final result = await addProgressEntryUseCase(entry);
    result.fold(
      (failure) => emit(ProgressError(failure.message)),
      (_) {}, // Stream will auto-update via Firestore listener
    );
  }

  Future<void> _onEntryDeleted(
    ProgressEntryDeleted event,
    Emitter<ProgressState> emit,
  ) async {
    final result = await progressRepository.deleteProgressEntry(event.entryId);
    result.fold(
      (failure) => emit(ProgressError(failure.message)),
      (_) {}, // Stream will auto-update
    );
  }

  @override
  Future<void> close() {
    _progressSub?.cancel();
    return super.close();
  }
}
