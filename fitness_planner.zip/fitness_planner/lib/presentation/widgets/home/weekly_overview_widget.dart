import 'package:flutter/material.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/core/utils/date_utils.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';

class WeeklyOverviewWidget extends StatelessWidget {
  final List<WorkoutEntity> workouts;
  const WeeklyOverviewWidget({super.key, required this.workouts});

  @override
  Widget build(BuildContext context) {
    final weekDays = AppDateUtils.getCurrentWeekDays();
    final today = DateTime.now();

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: weekDays.map((day) {
        final dayName = AppDateUtils.formatDay(day);
        final shortName = AppDateUtils.formatShortDay(day);
        final isToday = AppDateUtils.isSameDay(day, today);
        final isPast = day.isBefore(today) && !isToday;

        final dayWorkouts =
            workouts.where((w) => w.targetDays.contains(dayName)).toList();
        final hasWorkout = dayWorkouts.isNotEmpty;
        final isCompleted = dayWorkouts.any(
          (w) => w.status == WorkoutStatus.completed,
        );

        Color dotColor;
        if (isCompleted) {
          dotColor = AppTheme.success;
        } else if (hasWorkout && isPast) {
          dotColor = AppTheme.error;
        } else if (hasWorkout) {
          dotColor = AppTheme.primary;
        } else {
          dotColor = AppTheme.bgCardLight;
        }

        return Expanded(
          child: Column(
            children: [
              Text(
                shortName.substring(0, 1),
                style: TextStyle(
                  color: isToday ? AppTheme.primary : AppTheme.textMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: isToday
                      ? AppTheme.primary.withOpacity(0.15)
                      : Colors.transparent,
                  border: Border.all(
                    color: isToday ? AppTheme.primary : Colors.transparent,
                    width: 2,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    day.day.toString(),
                    style: TextStyle(
                      color:
                          isToday ? AppTheme.primary : AppTheme.textSecondary,
                      fontWeight: isToday ? FontWeight.w800 : FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              // Workout dot
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: dotColor,
                  shape: BoxShape.circle,
                ),
              ),
              if (isCompleted)
                const Icon(Icons.check, color: AppTheme.success, size: 10)
              else
                const SizedBox(height: 10),
            ],
          ),
        );
      }).toList(),
    );
  }
}
