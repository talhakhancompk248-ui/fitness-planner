import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

class TodayWorkoutCard extends StatelessWidget {
  final WorkoutEntity workout;
  const TodayWorkoutCard({super.key, required this.workout});

  Color get _difficultyColor {
    switch (workout.difficulty) {
      case WorkoutDifficulty.beginner:
        return AppTheme.success;
      case WorkoutDifficulty.intermediate:
        return AppTheme.warning;
      case WorkoutDifficulty.advanced:
        return AppTheme.error;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isCompleted = workout.status == WorkoutStatus.completed;

    return GestureDetector(
      onTap: () => context.push('/workout/${workout.id}'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isCompleted
                ? AppTheme.success.withOpacity(0.4)
                : const Color(0xFF1E2940),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        workout.name,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          _chip(
                            workout.difficulty.name,
                            _difficultyColor,
                          ),
                          const SizedBox(width: 8),
                          _chip(
                            '${workout.totalExercises} exercises',
                            AppTheme.info,
                          ),
                          if (workout.estimatedDuration != null) ...[
                            const SizedBox(width: 8),
                            _chip(
                              '${workout.estimatedDuration}min',
                              AppTheme.textSecondary,
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                if (isCompleted)
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.success.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.check_circle,
                      color: AppTheme.success,
                      size: 24,
                    ),
                  )
                else
                  ElevatedButton(
                    onPressed: () => context.push('/workout/${workout.id}'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                    ),
                    child: const Text('Start'),
                  ),
              ],
            ),
            if (!isCompleted && workout.progressPercent > 0) ...[
              const SizedBox(height: 12),
              LinearPercentIndicator(
                lineHeight: 6,
                percent: workout.progressPercent,
                backgroundColor: AppTheme.bgCardLight,
                progressColor: AppTheme.primary,
                barRadius: const Radius.circular(3),
                padding: EdgeInsets.zero,
              ),
              const SizedBox(height: 4),
              Text(
                '${workout.completedExercises}/${workout.totalExercises} exercises done',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
