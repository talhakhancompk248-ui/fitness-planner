import 'package:flutter/material.dart';
import 'package:fitness_planner/core/theme/app_theme.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';

class StatsRowWidget extends StatelessWidget {
  final List<WorkoutEntity> workouts;
  const StatsRowWidget({super.key, required this.workouts});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));

    final completedThisWeek = workouts.where((w) {
      return w.status == WorkoutStatus.completed &&
          w.completedAt != null &&
          w.completedAt!.isAfter(startOfWeek);
    }).length;

    final totalThisWeek = workouts.where((w) => w.targetDays.isNotEmpty).length;

    final totalVolume = workouts
        .where((w) => w.status == WorkoutStatus.completed)
        .fold(0, (sum, w) => sum + w.totalVolume);

    final streak = _calculateStreak(workouts);

    return Row(
      children: [
        _StatCard(
          label: 'This Week',
          value: '$completedThisWeek',
          suffix: '/ ${totalThisWeek == 0 ? "—" : totalThisWeek.toString()}',
          icon: Icons.calendar_today,
          color: AppTheme.primary,
        ),
        const SizedBox(width: 10),
        _StatCard(
          label: 'Streak',
          value: '$streak',
          suffix: 'days',
          icon: Icons.local_fire_department,
          color: AppTheme.secondary,
        ),
        const SizedBox(width: 10),
        _StatCard(
          label: 'Volume',
          value: totalVolume > 1000
              ? '${(totalVolume / 1000).toStringAsFixed(1)}k'
              : '$totalVolume',
          suffix: 'kg',
          icon: Icons.fitness_center,
          color: AppTheme.accent,
        ),
      ],
    );
  }

  int _calculateStreak(List<WorkoutEntity> workouts) {
    final completed = workouts
        .where(
            (w) => w.status == WorkoutStatus.completed && w.completedAt != null)
        .toList()
      ..sort((a, b) => b.completedAt!.compareTo(a.completedAt!));

    if (completed.isEmpty) return 0;

    int streak = 0;
    DateTime checkDate = DateTime.now();

    for (final workout in completed) {
      final completedDate = workout.completedAt!;
      final diff = checkDate.difference(completedDate).inDays;
      if (diff <= 1) {
        streak++;
        checkDate = completedDate.subtract(const Duration(days: 1));
      } else {
        break;
      }
    }
    return streak;
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String suffix;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.suffix,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFF1E2940)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 8),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: value,
                    style: TextStyle(
                      color: color,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  TextSpan(
                    text: ' $suffix',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: const TextStyle(
                color: AppTheme.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
