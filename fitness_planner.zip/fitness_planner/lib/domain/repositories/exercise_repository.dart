import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/exercise_entity.dart';

abstract class ExerciseRepository {
  Future<Result<List<ExerciseEntity>>> getExercises({
    String? muscleGroup,
    String? equipment,
    String? difficulty,
    String? query,
  });
  Future<Result<ExerciseEntity>> getExerciseById(String id);
  Future<Result<ExerciseEntity>> createCustomExercise(ExerciseEntity exercise);
  Future<Result<void>> deleteCustomExercise(String id);
  Future<Result<List<ExerciseEntity>>> getCustomExercises(String userId);
}
