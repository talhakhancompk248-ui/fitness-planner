import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/ai_suggestion_entity.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/entities/chat_message_entity.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';

abstract class AiRepository {
  Future<Result<String>> generateWorkoutPlan({
    required UserEntity user,
    required int availableDays,
  });

  Future<Result<String>> getImprovementSuggestions({
    required UserEntity user,
    required List<WorkoutEntity> recentWorkouts,
  });

  Future<Result<String>> getDailyTip({
    required UserEntity user,
  });

  Future<Result<String>> getDietSuggestions({
    required UserEntity user,
  });

  Future<Result<void>> saveSuggestion(AiSuggestionEntity suggestion);
  Future<Result<List<AiSuggestionEntity>>> getSavedSuggestions(String userId);

  // Chat Methods
  Future<Result<String>> chatWithAi(UserEntity user, String message);
  Future<Result<void>> saveChatMessage(ChatMessageEntity message);
  Future<Result<List<ChatMessageEntity>>> getChatHistory(String userId);
  Future<Result<void>> deleteChatMessage(String messageId);
  Future<Result<void>> clearChatHistory(String userId);
}
