import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';

abstract class UserRepository {
  Future<Result<UserEntity>> getUserProfile(String userId);
  Future<Result<void>> updateUserProfile(UserEntity user);
  Future<Result<void>> createUserProfile(UserEntity user);
}
