import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/progress_entry_entity.dart';

abstract class ProgressRepository {
  Stream<List<ProgressEntryEntity>> watchProgress(String userId);
  Future<Result<List<ProgressEntryEntity>>> getProgressEntries(String userId,
      {DateTime? from, DateTime? to});
  Future<Result<ProgressEntryEntity>> addProgressEntry(
    ProgressEntryEntity entry,
  );
  Future<Result<void>> deleteProgressEntry(String id);
}
