import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';

abstract class WorkoutRepository {
  Stream<List<WorkoutEntity>> watchUserWorkouts(String userId);
  Future<Result<List<WorkoutEntity>>> getUserWorkouts(String userId);
  Future<Result<WorkoutEntity>> getWorkoutById(String id);
  Future<Result<WorkoutEntity>> createWorkout(WorkoutEntity workout);
  Future<Result<WorkoutEntity>> updateWorkout(WorkoutEntity workout);
  Future<Result<void>> deleteWorkout(String id);
  Future<Result<List<WorkoutEntity>>> getWorkoutsByDay(
    String userId,
    String day,
  );
  Future<Result<List<WorkoutEntity>>> getCompletedWorkouts(String userId,
      {DateTime? from, DateTime? to});
}
