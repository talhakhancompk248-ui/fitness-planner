import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';

abstract class AuthRepository {
  Stream<UserEntity?> get authStateChanges;
  Future<Result<UserEntity>> signInWithEmail(String email, String password);
  Future<Result<UserEntity>> signUpWithEmail(
    String email,
    String password,
    String name,
  );
  Future<Result<void>> signOut();
  Future<Result<void>> resetPassword(String email);
  Future<UserEntity?> getCurrentUser();
}
