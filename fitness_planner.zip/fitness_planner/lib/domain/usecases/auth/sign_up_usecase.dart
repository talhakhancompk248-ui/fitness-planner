import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/repositories/auth_repository.dart';

class SignUpUseCase {
  final AuthRepository _repository;
  SignUpUseCase(this._repository);

  Future<Result<UserEntity>> call(
    String email,
    String password,
    String name,
  ) {
    return _repository.signUpWithEmail(email, password, name);
  }
}
