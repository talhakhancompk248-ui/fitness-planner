import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/repositories/auth_repository.dart';

class SignInUseCase {
  final AuthRepository _repository;
  SignInUseCase(this._repository);

  Future<Result<UserEntity>> call(String email, String password) {
    return _repository.signInWithEmail(email, password);
  }
}
