import '../../entities/progress_entry_entity.dart';
import '../../repositories/progress_repository.dart';
import '../../../core/utils/result.dart';

class AddProgressEntryUseCase {
  final ProgressRepository repository;

  AddProgressEntryUseCase(this.repository);

  Future<Result<void>> call(ProgressEntryEntity entry) async {
    return await repository.addProgressEntry(entry);
  }
}
