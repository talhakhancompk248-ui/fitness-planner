import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';

class GetImprovementSuggestionsUseCase {
  final AiRepository _repository;
  GetImprovementSuggestionsUseCase(this._repository);

  Future<Result<String>> call(
    UserEntity user,
    List<WorkoutEntity> recentWorkouts,
  ) {
    return _repository.getImprovementSuggestions(
      user: user,
      recentWorkouts: recentWorkouts,
    );
  }
}
