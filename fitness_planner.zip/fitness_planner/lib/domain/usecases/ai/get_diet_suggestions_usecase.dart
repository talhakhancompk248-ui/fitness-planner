import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';

class GetDietSuggestionsUseCase {
  final AiRepository _repository;
  GetDietSuggestionsUseCase(this._repository);

  Future<Result<String>> call(UserEntity user) {
    return _repository.getDietSuggestions(user: user);
  }
}
