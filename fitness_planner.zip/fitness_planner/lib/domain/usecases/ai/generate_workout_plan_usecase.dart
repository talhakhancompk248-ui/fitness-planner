import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';

class GenerateWorkoutPlanUseCase {
  final AiRepository _repository;
  GenerateWorkoutPlanUseCase(this._repository);

  Future<Result<String>> call(UserEntity user, int availableDays) {
    return _repository.generateWorkoutPlan(
      user: user,
      availableDays: availableDays,
    );
  }
}
