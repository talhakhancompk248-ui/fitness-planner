import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/progress_entry_entity.dart';
import 'package:fitness_planner/domain/repositories/progress_repository.dart';

class AddProgressEntryUseCase {
  final ProgressRepository _repository;
  AddProgressEntryUseCase(this._repository);

  Future<Result<ProgressEntryEntity>> call(ProgressEntryEntity entry) {
    return _repository.addProgressEntry(entry);
  }
}
