import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';

class GetDailyTipUseCase {
  final AiRepository _repository;
  GetDailyTipUseCase(this._repository);

  Future<Result<String>> call(UserEntity user) {
    return _repository.getDailyTip(user: user);
  }
}
