import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/workout_repository.dart';

class GetWorkoutsByDayUseCase {
  final WorkoutRepository _repository;
  GetWorkoutsByDayUseCase(this._repository);

  Future<Result<List<WorkoutEntity>>> call(String userId, String day) {
    return _repository.getWorkoutsByDay(userId, day);
  }
}
