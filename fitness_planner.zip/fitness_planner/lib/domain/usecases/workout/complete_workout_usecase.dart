import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/workout_repository.dart';

class CompleteWorkoutUseCase {
  final WorkoutRepository _repository;
  CompleteWorkoutUseCase(this._repository);

  Future<Result<WorkoutEntity>> call(WorkoutEntity workout) {
    final completed = workout.copyWith(
      status: WorkoutStatus.completed,
      completedAt: DateTime.now(),
    );
    return _repository.updateWorkout(completed);
  }
}
