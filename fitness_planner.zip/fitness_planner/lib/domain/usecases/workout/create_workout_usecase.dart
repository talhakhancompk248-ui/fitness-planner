import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/workout_repository.dart';

class CreateWorkoutUseCase {
  final WorkoutRepository _repository;
  CreateWorkoutUseCase(this._repository);

  Future<Result<WorkoutEntity>> call(WorkoutEntity workout) {
    return _repository.createWorkout(workout);
  }
}
