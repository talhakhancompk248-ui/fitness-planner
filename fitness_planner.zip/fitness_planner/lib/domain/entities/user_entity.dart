import 'package:equatable/equatable.dart';

class UserEntity extends Equatable {
  final String id;
  final String email;
  final String name;
  final String? photoUrl;
  final double? height; // cm
  final double? weight; // kg
  final String fitnessGoal;
  final int? age;
  final String? gender;
  final int? weeklyWorkoutDays;
  final String? fitnessLevel;
  final DateTime createdAt;

  const UserEntity({
    required this.id,
    required this.email,
    required this.name,
    this.photoUrl,
    this.height,
    this.weight,
    required this.fitnessGoal,
    this.age,
    this.gender,
    this.weeklyWorkoutDays,
    this.fitnessLevel,
    required this.createdAt,
  });

  double? get bmi {
    if (height == null || weight == null || height == 0) return null;
    final heightM = height! / 100;
    return weight! / (heightM * heightM);
  }

  String get bmiCategory {
    final b = bmi;
    if (b == null) return 'Unknown';
    if (b < 18.5) return 'Underweight';
    if (b < 25) return 'Normal';
    if (b < 30) return 'Overweight';
    return 'Obese';
  }

  UserEntity copyWith({
    String? name,
    String? photoUrl,
    double? height,
    double? weight,
    String? fitnessGoal,
    int? age,
    String? gender,
    int? weeklyWorkoutDays,
    String? fitnessLevel,
  }) {
    return UserEntity(
      id: id,
      email: email,
      name: name ?? this.name,
      photoUrl: photoUrl ?? this.photoUrl,
      height: height ?? this.height,
      weight: weight ?? this.weight,
      fitnessGoal: fitnessGoal ?? this.fitnessGoal,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      weeklyWorkoutDays: weeklyWorkoutDays ?? this.weeklyWorkoutDays,
      fitnessLevel: fitnessLevel ?? this.fitnessLevel,
      createdAt: createdAt,
    );
  }

  @override
  List<Object?> get props => [
    id,
    email,
    name,
    photoUrl,
    height,
    weight,
    fitnessGoal,
    age,
    gender,
    weeklyWorkoutDays,
    fitnessLevel,
    createdAt,
  ];
}
