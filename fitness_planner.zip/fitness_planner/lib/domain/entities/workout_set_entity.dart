import 'package:equatable/equatable.dart';

class WorkoutSetEntity extends Equatable {
  final String id;
  final int setNumber;
  final int? targetReps;
  final int? targetWeight; // kg
  final int? targetDuration; // seconds
  final bool isCompleted;
  final int? actualReps;
  final int? actualWeight;
  final int? actualDuration;

  const WorkoutSetEntity({
    required this.id,
    required this.setNumber,
    this.targetReps,
    this.targetWeight,
    this.targetDuration,
    this.isCompleted = false,
    this.actualReps,
    this.actualWeight,
    this.actualDuration,
  });

  WorkoutSetEntity copyWith({
    bool? isCompleted,
    int? actualReps,
    int? actualWeight,
    int? actualDuration,
  }) {
    return WorkoutSetEntity(
      id: id,
      setNumber: setNumber,
      targetReps: targetReps,
      targetWeight: targetWeight,
      targetDuration: targetDuration,
      isCompleted: isCompleted ?? this.isCompleted,
      actualReps: actualReps ?? this.actualReps,
      actualWeight: actualWeight ?? this.actualWeight,
      actualDuration: actualDuration ?? this.actualDuration,
    );
  }

  @override
  List<Object?> get props => [
        id,
        setNumber,
        targetReps,
        targetWeight,
        targetDuration,
        isCompleted,
        actualReps,
        actualWeight,
        actualDuration,
      ];
}
