import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

enum MessageSender { user, ai }

class ChatMessageEntity extends Equatable {
  final String id;
  final String userId;
  final MessageSender sender;
  final String content;
  final DateTime timestamp;

  const ChatMessageEntity({
    required this.id,
    required this.userId,
    required this.sender,
    required this.content,
    required this.timestamp,
  });

  @override
  List<Object?> get props => [id, userId, sender, content, timestamp];

  Map<String, dynamic> toDocument() {
    return {
      'userId': userId,
      'sender': sender.name,
      'content': content,
      'timestamp': Timestamp.fromDate(timestamp),
    };
  }

  factory ChatMessageEntity.fromDocument(Map<String, dynamic> doc, String id) {
    return ChatMessageEntity(
      id: id,
      userId: doc['userId'] as String,
      sender: MessageSender.values.firstWhere((e) => e.name == doc['sender']),
      content: doc['content'] as String,
      timestamp: (doc['timestamp'] as Timestamp).toDate(),
    );
  }
}
