import 'package:equatable/equatable.dart';

class ExerciseEntity extends Equatable {
  final String id;
  final String name;
  final String muscleGroup;
  final String equipment;
  final String difficulty;
  final String? description;
  final String? imageUrl;
  final List<String> instructions;
  final bool isCustom;
  final String? createdBy;

  const ExerciseEntity({
    required this.id,
    required this.name,
    required this.muscleGroup,
    required this.equipment,
    required this.difficulty,
    this.description,
    this.imageUrl,
    this.instructions = const [],
    this.isCustom = false,
    this.createdBy,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        muscleGroup,
        equipment,
        difficulty,
        description,
        imageUrl,
        instructions,
        isCustom,
        createdBy,
      ];
}
