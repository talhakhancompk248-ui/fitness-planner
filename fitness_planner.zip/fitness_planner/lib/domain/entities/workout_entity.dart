import 'package:equatable/equatable.dart';
import 'workout_exercise_entity.dart';

enum WorkoutDifficulty { beginner, intermediate, advanced }

enum WorkoutStatus { planned, inProgress, completed, skipped }

class WorkoutEntity extends Equatable {
  final String id;
  final String name;
  final String? description;
  final List<String> targetDays; // ['Monday', 'Thursday']
  final List<WorkoutExerciseEntity> exercises;
  final WorkoutDifficulty difficulty;
  final WorkoutStatus status;
  final int? estimatedDuration; // minutes
  final String? userId;
  final bool isTemplate;
  final DateTime createdAt;
  final DateTime? completedAt;

  const WorkoutEntity({
    required this.id,
    required this.name,
    this.description,
    required this.targetDays,
    required this.exercises,
    required this.difficulty,
    this.status = WorkoutStatus.planned,
    this.estimatedDuration,
    this.userId,
    this.isTemplate = false,
    required this.createdAt,
    this.completedAt,
  });

  int get totalExercises => exercises.length;
  int get completedExercises => exercises.where((e) => e.isCompleted).length;
  double get progressPercent =>
      totalExercises == 0 ? 0 : completedExercises / totalExercises;

  int get totalVolume => exercises.fold(0, (sum, ex) => sum + ex.totalVolume);

  WorkoutEntity copyWith({
    String? name,
    String? description,
    List<String>? targetDays,
    List<WorkoutExerciseEntity>? exercises,
    WorkoutDifficulty? difficulty,
    WorkoutStatus? status,
    int? estimatedDuration,
    DateTime? completedAt,
  }) {
    return WorkoutEntity(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      targetDays: targetDays ?? this.targetDays,
      exercises: exercises ?? this.exercises,
      difficulty: difficulty ?? this.difficulty,
      status: status ?? this.status,
      estimatedDuration: estimatedDuration ?? this.estimatedDuration,
      userId: userId,
      isTemplate: isTemplate,
      createdAt: createdAt,
      completedAt: completedAt ?? this.completedAt,
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        description,
        targetDays,
        exercises,
        difficulty,
        status,
        estimatedDuration,
        userId,
        isTemplate,
        createdAt,
        completedAt,
      ];
}
