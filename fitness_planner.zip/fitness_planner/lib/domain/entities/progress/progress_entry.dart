class ProgressEntry {
  final String id;
  final double weight;
  final double bmi;
  final DateTime date;
  final String notes;

  ProgressEntry({
    required this.id,
    required this.weight,
    required this.bmi,
    required this.date,
    required this.notes,
  });
}
