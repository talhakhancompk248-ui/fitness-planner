import 'package:equatable/equatable.dart';
import 'exercise_entity.dart';
import 'workout_set_entity.dart';

class WorkoutExerciseEntity extends Equatable {
  final String id;
  final ExerciseEntity exercise;
  final List<WorkoutSetEntity> sets;
  final String? notes;
  final int orderIndex;

  const WorkoutExerciseEntity({
    required this.id,
    required this.exercise,
    required this.sets,
    this.notes,
    required this.orderIndex,
  });

  int get totalVolume {
    return sets.fold(0, (sum, set) {
      if (set.actualReps != null && set.actualWeight != null) {
        return sum + (set.actualReps! * set.actualWeight!);
      }
      return sum;
    });
  }

  int get completedSets => sets.where((s) => s.isCompleted).length;
  bool get isCompleted => sets.isNotEmpty && completedSets == sets.length;

  @override
  List<Object?> get props => [id, exercise, sets, notes, orderIndex];
}
