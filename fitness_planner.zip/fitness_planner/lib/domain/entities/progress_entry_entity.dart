import 'package:equatable/equatable.dart';

class ProgressEntryEntity extends Equatable {
  final String id;
  final String userId;
  final DateTime date;
  final double? weight;
  final double? bodyFatPercent;
  final double? chestCm;
  final double? waistCm;
  final double? hipsCm;
  final double? armCm;
  final double? thighCm;
  final String? notes;

  const ProgressEntryEntity({
    required this.id,
    required this.userId,
    required this.date,
    this.weight,
    this.bodyFatPercent,
    this.chestCm,
    this.waistCm,
    this.hipsCm,
    this.armCm,
    this.thighCm,
    this.notes,
  });

  @override
  List<Object?> get props => [
        id,
        userId,
        date,
        weight,
        bodyFatPercent,
        chestCm,
        waistCm,
        hipsCm,
        armCm,
        thighCm,
        notes,
      ];
}
