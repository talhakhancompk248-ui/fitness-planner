import 'package:equatable/equatable.dart';

enum SuggestionType { workoutPlan, improvement, tip, diet }

class AiSuggestionEntity extends Equatable {
  final String id;
  final SuggestionType type;
  final String title;
  final String content;
  final DateTime generatedAt;
  final bool isRead;
  final Map<String, dynamic>? metadata;

  const AiSuggestionEntity({
    required this.id,
    required this.type,
    required this.title,
    required this.content,
    required this.generatedAt,
    this.isRead = false,
    this.metadata,
  });

  @override
  List<Object?> get props => [
        id,
        type,
        title,
        content,
        generatedAt,
        isRead,
        metadata,
      ];
}
