import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/domain/entities/progress_entry_entity.dart';

class ProgressModel extends ProgressEntryEntity {
  const ProgressModel({
    required super.id,
    required super.userId,
    required super.date,
    super.weight,
    super.bodyFatPercent,
    super.chestCm,
    super.waistCm,
    super.hipsCm,
    super.armCm,
    super.thighCm,
    super.notes,
  });

  factory ProgressModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ProgressModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      date: (data['date'] as Timestamp).toDate(),
      weight: (data['weight'] as num?)?.toDouble(),
      bodyFatPercent: (data['bodyFatPercent'] as num?)?.toDouble(),
      chestCm: (data['chestCm'] as num?)?.toDouble(),
      waistCm: (data['waistCm'] as num?)?.toDouble(),
      hipsCm: (data['hipsCm'] as num?)?.toDouble(),
      armCm: (data['armCm'] as num?)?.toDouble(),
      thighCm: (data['thighCm'] as num?)?.toDouble(),
      notes: data['notes'],
    );
  }

  Map<String, dynamic> toFirestore() => {
        'userId': userId,
        'date': Timestamp.fromDate(date),
        'weight': weight,
        'bodyFatPercent': bodyFatPercent,
        'chestCm': chestCm,
        'waistCm': waistCm,
        'hipsCm': hipsCm,
        'armCm': armCm,
        'thighCm': thighCm,
        'notes': notes,
      };
}
