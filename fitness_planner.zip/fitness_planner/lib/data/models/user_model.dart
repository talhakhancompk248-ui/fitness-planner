import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  const UserModel({
    required super.id,
    required super.email,
    required super.name,
    super.photoUrl,
    super.height,
    super.weight,
    required super.fitnessGoal,
    super.age,
    super.gender,
    super.weeklyWorkoutDays,
    super.fitnessLevel,
    required super.createdAt,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      id: doc.id,
      email: data['email'] ?? '',
      name: data['name'] ?? '',
      photoUrl: data['photoUrl'],
      height: (data['height'] as num?)?.toDouble(),
      weight: (data['weight'] as num?)?.toDouble(),
      fitnessGoal: data['fitnessGoal'] ?? 'Maintain',
      age: data['age'],
      gender: data['gender'],
      weeklyWorkoutDays: data['weeklyWorkoutDays'],
      fitnessLevel: data['fitnessLevel'],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  factory UserModel.fromEntity(UserEntity entity) => UserModel(
        id: entity.id,
        email: entity.email,
        name: entity.name,
        photoUrl: entity.photoUrl,
        height: entity.height,
        weight: entity.weight,
        fitnessGoal: entity.fitnessGoal,
        age: entity.age,
        gender: entity.gender,
        weeklyWorkoutDays: entity.weeklyWorkoutDays,
        fitnessLevel: entity.fitnessLevel,
        createdAt: entity.createdAt,
      );

  Map<String, dynamic> toFirestore() => {
        'email': email,
        'name': name,
        'photoUrl': photoUrl,
        'height': height,
        'weight': weight,
        'fitnessGoal': fitnessGoal,
        'age': age,
        'gender': gender,
        'weeklyWorkoutDays': weeklyWorkoutDays,
        'fitnessLevel': fitnessLevel,
        'createdAt': Timestamp.fromDate(createdAt),
      };
}
