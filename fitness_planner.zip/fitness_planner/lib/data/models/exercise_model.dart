import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/domain/entities/exercise_entity.dart';

class ExerciseModel extends ExerciseEntity {
  const ExerciseModel({
    required super.id,
    required super.name,
    required super.muscleGroup,
    required super.equipment,
    required super.difficulty,
    super.description,
    super.imageUrl,
    super.instructions,
    super.isCustom,
    super.createdBy,
  });

  factory ExerciseModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ExerciseModel(
      id: doc.id,
      name: data['name'] ?? '',
      muscleGroup: data['muscleGroup'] ?? '',
      equipment: data['equipment'] ?? 'Bodyweight',
      difficulty: data['difficulty'] ?? 'Beginner',
      description: data['description'],
      imageUrl: data['imageUrl'],
      instructions: List<String>.from(data['instructions'] ?? []),
      isCustom: data['isCustom'] ?? false,
      createdBy: data['createdBy'],
    );
  }

  factory ExerciseModel.fromMap(Map<String, dynamic> data, String id) =>
      ExerciseModel(
        id: id,
        name: data['name'] ?? '',
        muscleGroup: data['muscleGroup'] ?? '',
        equipment: data['equipment'] ?? 'Bodyweight',
        difficulty: data['difficulty'] ?? 'Beginner',
        description: data['description'],
        imageUrl: data['imageUrl'],
        instructions: List<String>.from(data['instructions'] ?? []),
        isCustom: data['isCustom'] ?? false,
        createdBy: data['createdBy'],
      );

  Map<String, dynamic> toFirestore() => {
        'name': name,
        'muscleGroup': muscleGroup,
        'equipment': equipment,
        'difficulty': difficulty,
        'description': description,
        'imageUrl': imageUrl,
        'instructions': instructions,
        'isCustom': isCustom,
        'createdBy': createdBy,
      };
}
