import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/entities/workout_exercise_entity.dart';
import 'package:fitness_planner/domain/entities/workout_set_entity.dart';
import 'exercise_model.dart';

class WorkoutModel extends WorkoutEntity {
  const WorkoutModel({
    required super.id,
    required super.name,
    super.description,
    required super.targetDays,
    required super.exercises,
    required super.difficulty,
    super.status,
    super.estimatedDuration,
    super.userId,
    super.isTemplate,
    required super.createdAt,
    super.completedAt,
  });

  factory WorkoutModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return WorkoutModel(
      id: doc.id,
      name: data['name'] ?? '',
      description: data['description'],
      targetDays: List<String>.from(data['targetDays'] ?? []),
      exercises: _parseExercises(data['exercises'] ?? []),
      difficulty: _parseDifficulty(data['difficulty']),
      status: _parseStatus(data['status']),
      estimatedDuration: data['estimatedDuration'],
      userId: data['userId'],
      isTemplate: data['isTemplate'] ?? false,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      completedAt: (data['completedAt'] as Timestamp?)?.toDate(),
    );
  }

  static List<WorkoutExerciseEntity> _parseExercises(List<dynamic> raw) {
    return raw.map((e) {
      final map = e as Map<String, dynamic>;
      final exerciseData = map['exercise'] as Map<String, dynamic>;
      final exercise = ExerciseModel.fromMap(
        exerciseData,
        exerciseData['id'] ?? '',
      );
      final sets = (map['sets'] as List<dynamic>?)?.map((s) {
            final setMap = s as Map<String, dynamic>;
            return WorkoutSetEntity(
              id: setMap['id'] ?? '',
              setNumber: setMap['setNumber'] ?? 1,
              targetReps: setMap['targetReps'],
              targetWeight: setMap['targetWeight'],
              targetDuration: setMap['targetDuration'],
              isCompleted: setMap['isCompleted'] ?? false,
              actualReps: setMap['actualReps'],
              actualWeight: setMap['actualWeight'],
              actualDuration: setMap['actualDuration'],
            );
          }).toList() ??
          [];

      return WorkoutExerciseEntity(
        id: map['id'] ?? '',
        exercise: exercise,
        sets: sets,
        notes: map['notes'],
        orderIndex: map['orderIndex'] ?? 0,
      );
    }).toList();
  }

  static WorkoutDifficulty _parseDifficulty(String? val) {
    switch (val) {
      case 'intermediate':
        return WorkoutDifficulty.intermediate;
      case 'advanced':
        return WorkoutDifficulty.advanced;
      default:
        return WorkoutDifficulty.beginner;
    }
  }

  static WorkoutStatus _parseStatus(String? val) {
    switch (val) {
      case 'inProgress':
        return WorkoutStatus.inProgress;
      case 'completed':
        return WorkoutStatus.completed;
      case 'skipped':
        return WorkoutStatus.skipped;
      default:
        return WorkoutStatus.planned;
    }
  }

  Map<String, dynamic> toFirestore() => {
        'name': name,
        'description': description,
        'targetDays': targetDays,
        'exercises': exercises
            .map((e) => {
                  'id': e.id,
                  'orderIndex': e.orderIndex,
                  'notes': e.notes,
                  'exercise': {
                    'id': e.exercise.id,
                    'name': e.exercise.name,
                    'muscleGroup': e.exercise.muscleGroup,
                    'equipment': e.exercise.equipment,
                    'difficulty': e.exercise.difficulty,
                    'imageUrl': e.exercise.imageUrl,
                  },
                  'sets': e.sets
                      .map((s) => {
                            'id': s.id,
                            'setNumber': s.setNumber,
                            'targetReps': s.targetReps,
                            'targetWeight': s.targetWeight,
                            'targetDuration': s.targetDuration,
                            'isCompleted': s.isCompleted,
                            'actualReps': s.actualReps,
                            'actualWeight': s.actualWeight,
                            'actualDuration': s.actualDuration,
                          })
                      .toList(),
                })
            .toList(),
        'difficulty': difficulty.name,
        'status': status.name,
        'estimatedDuration': estimatedDuration,
        'userId': userId,
        'isTemplate': isTemplate,
        'createdAt': Timestamp.fromDate(createdAt),
        'completedAt':
            completedAt != null ? Timestamp.fromDate(completedAt!) : null,
      };
}
