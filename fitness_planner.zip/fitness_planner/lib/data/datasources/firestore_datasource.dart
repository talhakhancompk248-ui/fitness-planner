import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/errors/exceptions.dart';
import 'package:fitness_planner/data/models/exercise_model.dart';
import 'package:fitness_planner/data/models/progress_model.dart';
import 'package:fitness_planner/data/models/user_model.dart';
import 'package:fitness_planner/data/models/workout_model.dart';

abstract class FirestoreDataSource {
  Future<UserModel> getUserProfile(String userId);
  Future<void> setUserProfile(UserModel user);
  Stream<List<WorkoutModel>> watchUserWorkouts(String userId);
  Future<List<WorkoutModel>> getUserWorkouts(String userId);
  Future<WorkoutModel> getWorkoutById(String id);
  Future<WorkoutModel> createWorkout(WorkoutModel workout);
  Future<WorkoutModel> updateWorkout(WorkoutModel workout);
  Future<void> deleteWorkout(String id);
  Future<List<ExerciseModel>> getExercises({
    String? muscleGroup,
    String? equipment,
    String? difficulty,
    String? query,
  });
  Future<ExerciseModel> createCustomExercise(ExerciseModel exercise);
  Future<void> deleteCustomExercise(String id);
  Stream<List<ProgressModel>> watchProgress(String userId);
  Future<List<ProgressModel>> getProgressEntries(String userId,
      {DateTime? from, DateTime? to});
  Future<ProgressModel> addProgressEntry(ProgressModel entry);
  Future<void> deleteProgressEntry(String id);
}

class FirestoreDataSourceImpl implements FirestoreDataSource {
  final FirebaseFirestore _db;
  FirestoreDataSourceImpl(this._db);

  @override
  Future<UserModel> getUserProfile(String userId) async {
    try {
      final doc =
          await _db.collection(AppConstants.usersCollection).doc(userId).get();
      if (!doc.exists) throw const ServerException('User not found');
      return UserModel.fromFirestore(doc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> setUserProfile(UserModel user) async {
    await _db
        .collection(AppConstants.usersCollection)
        .doc(user.id)
        .set(user.toFirestore(), SetOptions(merge: true));
  }

  @override
  Stream<List<WorkoutModel>> watchUserWorkouts(String userId) {
    return _db
        .collection(AppConstants.workoutsCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(WorkoutModel.fromFirestore).toList());
  }

  @override
  Future<List<WorkoutModel>> getUserWorkouts(String userId) async {
    final snap = await _db
        .collection(AppConstants.workoutsCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map(WorkoutModel.fromFirestore).toList();
  }

  @override
  Future<WorkoutModel> getWorkoutById(String id) async {
    final doc =
        await _db.collection(AppConstants.workoutsCollection).doc(id).get();
    if (!doc.exists) throw const ServerException('Workout not found');
    return WorkoutModel.fromFirestore(doc);
  }

  @override
  Future<WorkoutModel> createWorkout(WorkoutModel workout) async {
    final ref = await _db
        .collection(AppConstants.workoutsCollection)
        .add(workout.toFirestore());
    final doc = await ref.get();
    return WorkoutModel.fromFirestore(doc);
  }

  @override
  Future<WorkoutModel> updateWorkout(WorkoutModel workout) async {
    await _db
        .collection(AppConstants.workoutsCollection)
        .doc(workout.id)
        .update(workout.toFirestore());
    return workout;
  }

  @override
  Future<void> deleteWorkout(String id) async {
    await _db.collection(AppConstants.workoutsCollection).doc(id).delete();
  }

  @override
  Future<List<ExerciseModel>> getExercises({
    String? muscleGroup,
    String? equipment,
    String? difficulty,
    String? query,
  }) async {
    Query q = _db.collection(AppConstants.exercisesCollection);
    if (muscleGroup != null) q = q.where('muscleGroup', isEqualTo: muscleGroup);
    if (equipment != null) q = q.where('equipment', isEqualTo: equipment);
    if (difficulty != null) q = q.where('difficulty', isEqualTo: difficulty);
    final snap = await q.get();
    var results = snap.docs.map(ExerciseModel.fromFirestore).toList();
    if (query != null && query.isNotEmpty) {
      results = results
          .where((e) => e.name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    }
    return results;
  }

  @override
  Future<ExerciseModel> createCustomExercise(ExerciseModel exercise) async {
    final ref = await _db
        .collection(AppConstants.exercisesCollection)
        .add(exercise.toFirestore());
    final doc = await ref.get();
    return ExerciseModel.fromFirestore(doc);
  }

  @override
  Future<void> deleteCustomExercise(String id) async {
    await _db.collection(AppConstants.exercisesCollection).doc(id).delete();
  }

  @override
  Stream<List<ProgressModel>> watchProgress(String userId) {
    return _db
        .collection(AppConstants.progressCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: false)
        .snapshots()
        .map((snap) => snap.docs.map(ProgressModel.fromFirestore).toList());
  }

  @override
  Future<List<ProgressModel>> getProgressEntries(String userId,
      {DateTime? from, DateTime? to}) async {
    Query q = _db
        .collection(AppConstants.progressCollection)
        .where('userId', isEqualTo: userId);
    if (from != null) {
      q = q.where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(from));
    }
    if (to != null) {
      q = q.where('date', isLessThanOrEqualTo: Timestamp.fromDate(to));
    }
    final snap = await q.orderBy('date').get();
    return snap.docs.map(ProgressModel.fromFirestore).toList();
  }

  @override
  Future<ProgressModel> addProgressEntry(ProgressModel entry) async {
    final ref = await _db
        .collection(AppConstants.progressCollection)
        .add(entry.toFirestore());
    final doc = await ref.get();
    return ProgressModel.fromFirestore(doc);
  }

  @override
  Future<void> deleteProgressEntry(String id) async {
    await _db.collection(AppConstants.progressCollection).doc(id).delete();
  }
}
