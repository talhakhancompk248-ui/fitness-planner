import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/errors/exceptions.dart';
import 'package:fitness_planner/data/models/exercise_model.dart';
import 'package:fitness_planner/data/models/progress_model.dart';
import 'package:fitness_planner/data/models/user_model.dart';
import 'package:fitness_planner/data/models/workout_model.dart';

abstract class FirestoreDataSource {
  Future<UserModel> getUserProfile(String userId);

  Future<void> setUserProfile(UserModel user);

  Stream<List<WorkoutModel>> watchUserWorkouts(String userId);

  Future<List<WorkoutModel>> getUserWorkouts(String userId);

  Future<WorkoutModel> getWorkoutById(String id);

  Future<WorkoutModel> createWorkout(WorkoutModel workout);

  Future<WorkoutModel> updateWorkout(WorkoutModel workout);

  Future<void> deleteWorkout(String id);

  Future<List<ExerciseModel>> getExercises({
    String? muscleGroup,
    String? equipment,
    String? difficulty,
    String? query,
  });

  Future<ExerciseModel> createCustomExercise(ExerciseModel exercise);

  Future<void> deleteCustomExercise(String id);

  Stream<List<ProgressModel>> watchProgress(String userId);

  Future<List<ProgressModel>> getProgressEntries(
    String userId, {
    DateTime? from,
    DateTime? to,
  });

  Future<ProgressModel> addProgressEntry(ProgressModel entry);

  Future<void> deleteProgressEntry(String id);
}

class FirestoreDataSourceImpl implements FirestoreDataSource {
  final FirebaseFirestore _db;

  FirestoreDataSourceImpl(this._db);

  // =========================
  // USER
  // =========================

  @override
  Future<UserModel> getUserProfile(String userId) async {
    try {
      final doc =
          await _db.collection(AppConstants.usersCollection).doc(userId).get();

      if (!doc.exists) {
        throw const ServerException('User not found');
      }

      return UserModel.fromFirestore(doc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> setUserProfile(UserModel user) async {
    try {
      await _db.collection(AppConstants.usersCollection).doc(user.id).set(
            user.toFirestore(),
            SetOptions(merge: true),
          );
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  // =========================
  // WORKOUTS
  // =========================

  @override
  Stream<List<WorkoutModel>> watchUserWorkouts(String userId) {
    return _db
        .collection(AppConstants.workoutsCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => WorkoutModel.fromFirestore(doc))
              .toList(),
        );
  }

  @override
  Future<List<WorkoutModel>> getUserWorkouts(String userId) async {
    try {
      final snapshot = await _db
          .collection(AppConstants.workoutsCollection)
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      return snapshot.docs
          .map((doc) => WorkoutModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<WorkoutModel> getWorkoutById(String id) async {
    try {
      final doc =
          await _db.collection(AppConstants.workoutsCollection).doc(id).get();

      if (!doc.exists) {
        throw const ServerException('Workout not found');
      }

      return WorkoutModel.fromFirestore(doc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<WorkoutModel> createWorkout(WorkoutModel workout) async {
    try {
      final docRef =
          _db.collection(AppConstants.workoutsCollection).doc(workout.id);

      await docRef.set(workout.toFirestore());

      final doc = await docRef.get();

      return WorkoutModel.fromFirestore(doc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<WorkoutModel> updateWorkout(WorkoutModel workout) async {
    try {
      await _db
          .collection(AppConstants.workoutsCollection)
          .doc(workout.id)
          .update(workout.toFirestore());

      final updatedDoc = await _db
          .collection(AppConstants.workoutsCollection)
          .doc(workout.id)
          .get();

      return WorkoutModel.fromFirestore(updatedDoc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> deleteWorkout(String id) async {
    try {
      await _db.collection(AppConstants.workoutsCollection).doc(id).delete();
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  // =========================
  // EXERCISES
  // =========================

  @override
  Future<List<ExerciseModel>> getExercises({
    String? muscleGroup,
    String? equipment,
    String? difficulty,
    String? query,
  }) async {
    try {
      Query queryRef = _db.collection(AppConstants.exercisesCollection);

      if (muscleGroup != null && muscleGroup.isNotEmpty) {
        queryRef = queryRef.where(
          'muscleGroup',
          isEqualTo: muscleGroup,
        );
      }

      if (equipment != null && equipment.isNotEmpty) {
        queryRef = queryRef.where(
          'equipment',
          isEqualTo: equipment,
        );
      }

      if (difficulty != null && difficulty.isNotEmpty) {
        queryRef = queryRef.where(
          'difficulty',
          isEqualTo: difficulty,
        );
      }

      final snapshot = await queryRef.get();

      List<ExerciseModel> exercises =
          snapshot.docs.map((doc) => ExerciseModel.fromFirestore(doc)).toList();

      if (query != null && query.trim().isNotEmpty) {
        exercises = exercises.where((exercise) {
          return exercise.name.toLowerCase().contains(query.toLowerCase());
        }).toList();
      }

      return exercises;
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<ExerciseModel> createCustomExercise(
    ExerciseModel exercise,
  ) async {
    try {
      final docRef =
          _db.collection(AppConstants.exercisesCollection).doc(exercise.id);

      await docRef.set(exercise.toFirestore());

      final doc = await docRef.get();

      return ExerciseModel.fromFirestore(doc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> deleteCustomExercise(String id) async {
    try {
      await _db.collection(AppConstants.exercisesCollection).doc(id).delete();
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  // =========================
  // PROGRESS
  // =========================

  @override
  Stream<List<ProgressModel>> watchProgress(String userId) {
    return _db
        .collection(AppConstants.progressCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('date')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => ProgressModel.fromFirestore(doc))
              .toList(),
        );
  }

  @override
  Future<List<ProgressModel>> getProgressEntries(
    String userId, {
    DateTime? from,
    DateTime? to,
  }) async {
    try {
      Query queryRef = _db
          .collection(AppConstants.progressCollection)
          .where('userId', isEqualTo: userId);

      if (from != null) {
        queryRef = queryRef.where(
          'date',
          isGreaterThanOrEqualTo: Timestamp.fromDate(from),
        );
      }

      if (to != null) {
        queryRef = queryRef.where(
          'date',
          isLessThanOrEqualTo: Timestamp.fromDate(to),
        );
      }

      final snapshot = await queryRef.orderBy('date').get();

      return snapshot.docs
          .map((doc) => ProgressModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<ProgressModel> addProgressEntry(
    ProgressModel entry,
  ) async {
    try {
      final docRef =
          _db.collection(AppConstants.progressCollection).doc(entry.id);

      await docRef.set(entry.toFirestore());

      final doc = await docRef.get();

      return ProgressModel.fromFirestore(doc);
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> deleteProgressEntry(String id) async {
    try {
      await _db.collection(AppConstants.progressCollection).doc(id).delete();
    } catch (e) {
      throw ServerException(e.toString());
    }
  }
}
