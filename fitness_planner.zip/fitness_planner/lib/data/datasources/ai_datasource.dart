import 'package:dio/dio.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/errors/exceptions.dart';

abstract class AiDataSource {
  Future<String> chat(String systemPrompt, String userMessage);
}

class OpenRouterDataSource implements AiDataSource {
  final Dio _dio;

  OpenRouterDataSource(this._dio) {
    _dio.options = BaseOptions(
      baseUrl: AppConstants.openRouterBaseUrl,
      headers: {
        'Authorization': 'Bearer ${AppConstants.openRouterApiKey}',
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://fitness-planner-app.com',
        'X-Title': 'Fitness Planner',
      },
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 60),
    );
  }

  @override
  Future<String> chat(String systemPrompt, String userMessage) async {
    try {
      final response = await _dio.post('/chat/completions', data: {
        'model': AppConstants.aiModel,
        'messages': [
          {'role': 'system', 'content': systemPrompt},
          {'role': 'user', 'content': userMessage},
        ],
        'max_tokens': 1500,
        'temperature': 0.7,
      });

      final choices = response.data['choices'] as List;
      if (choices.isEmpty) throw const ServerException('No AI response');
      return choices.first['message']['content'] as String;
    } on DioException catch (e) {
      throw ServerException(
        e.response?.data?['error']?['message'] ?? 'AI request failed',
      );
    }
  }
}
