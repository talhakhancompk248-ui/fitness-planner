import 'package:fitness_planner/core/errors/exception_mapper.dart';
import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/data/datasources/firestore_datasource.dart';
import 'package:fitness_planner/data/models/workout_model.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/workout_repository.dart';

class WorkoutRepositoryImpl implements WorkoutRepository {
  final FirestoreDataSource _dataSource;
  WorkoutRepositoryImpl(this._dataSource);

  @override
  Stream<List<WorkoutEntity>> watchUserWorkouts(String userId) =>
      _dataSource.watchUserWorkouts(userId);

  @override
  Future<Result<List<WorkoutEntity>>> getUserWorkouts(String userId) async {
    try {
      final workouts = await _dataSource.getUserWorkouts(userId);
      return Result.success(workouts);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<WorkoutEntity>> getWorkoutById(String id) async {
    try {
      final workout = await _dataSource.getWorkoutById(id);
      return Result.success(workout);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<WorkoutEntity>> createWorkout(WorkoutEntity workout) async {
    try {
      final model = _toModel(workout);
      final created = await _dataSource.createWorkout(model);
      return Result.success(created);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<WorkoutEntity>> updateWorkout(WorkoutEntity workout) async {
    try {
      final model = _toModel(workout);
      final updated = await _dataSource.updateWorkout(model);
      return Result.success(updated);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> deleteWorkout(String id) async {
    try {
      await _dataSource.deleteWorkout(id);
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<List<WorkoutEntity>>> getWorkoutsByDay(
    String userId,
    String day,
  ) async {
    try {
      final all = await _dataSource.getUserWorkouts(userId);
      final filtered = all.where((w) => w.targetDays.contains(day)).toList();
      return Result.success(filtered);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<List<WorkoutEntity>>> getCompletedWorkouts(
    String userId, {
    DateTime? from,
    DateTime? to,
  }) async {
    try {
      final all = await _dataSource.getUserWorkouts(userId);
      var completed =
          all.where((w) => w.status == WorkoutStatus.completed).toList();
      if (from != null) {
        completed = completed
            .where((w) => w.completedAt != null && w.completedAt!.isAfter(from))
            .toList();
      }
      if (to != null) {
        completed = completed
            .where((w) => w.completedAt != null && w.completedAt!.isBefore(to))
            .toList();
      }
      return Result.success(completed);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  WorkoutModel _toModel(WorkoutEntity w) => WorkoutModel(
        id: w.id,
        name: w.name,
        description: w.description,
        targetDays: w.targetDays,
        exercises: w.exercises,
        difficulty: w.difficulty,
        status: w.status,
        estimatedDuration: w.estimatedDuration,
        userId: w.userId,
        isTemplate: w.isTemplate,
        createdAt: w.createdAt,
        completedAt: w.completedAt,
      );
}
