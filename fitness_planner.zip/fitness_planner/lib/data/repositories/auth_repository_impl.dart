import 'package:fitness_planner/core/errors/exception_mapper.dart';
import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/data/datasources/firebase_auth_datasource.dart';
import 'package:fitness_planner/data/datasources/firestore_datasource.dart';
import 'package:fitness_planner/data/models/user_model.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  final FirebaseAuthDataSource _authDataSource;
  final FirestoreDataSource _firestoreDataSource;

  AuthRepositoryImpl(this._authDataSource, this._firestoreDataSource);

  @override
  Stream<UserEntity?> get authStateChanges =>
      _authDataSource.authStateChanges.asyncMap((user) async {
        if (user == null) return null;
        try {
          return await _firestoreDataSource.getUserProfile(user.uid);
        } catch (_) {
          return null;
        }
      });

  @override
  Future<UserEntity?> getCurrentUser() async {
    final user = _authDataSource.getCurrentUser();
    if (user == null) return null;
    try {
      return await _firestoreDataSource.getUserProfile(user.uid);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<Result<UserEntity>> signInWithEmail(
    String email,
    String password,
  ) async {
    try {
      final user = await _authDataSource.signInWithEmail(email, password);
      final profile = await _firestoreDataSource.getUserProfile(user.uid);
      return Result.success(profile);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<UserEntity>> signUpWithEmail(
    String email,
    String password,
    String name,
  ) async {
    try {
      final user = await _authDataSource.signUpWithEmail(email, password);
      final userModel = UserModel(
        id: user.uid,
        email: email,
        name: name,
        fitnessGoal: 'Maintain',
        createdAt: DateTime.now(),
      );
      await _firestoreDataSource.setUserProfile(userModel);
      return Result.success(userModel);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> signOut() async {
    try {
      await _authDataSource.signOut();
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> resetPassword(String email) async {
    try {
      await _authDataSource.resetPassword(email);
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }
}
