import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_planner/core/constants/app_constants.dart';
import 'package:fitness_planner/core/errors/exceptions.dart';
import 'package:fitness_planner/core/errors/exception_mapper.dart';
import 'package:fitness_planner/core/errors/failures.dart';
import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/data/datasources/ai_datasource.dart';
import 'package:fitness_planner/domain/entities/ai_suggestion_entity.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/entities/chat_message_entity.dart';
import 'package:fitness_planner/domain/entities/workout_entity.dart';
import 'package:fitness_planner/domain/repositories/ai_repository.dart';

class AiRepositoryImpl implements AiRepository {
  final AiDataSource _aiDataSource;
  final FirebaseFirestore _db;

  AiRepositoryImpl(this._aiDataSource, this._db);

  static const String _systemPrompt = '''
You are an expert personal fitness coach and nutritionist.
Provide concise, actionable, science-backed advice.
Format responses clearly with sections and bullet points where helpful.
Keep advice practical, safe, and motivating.
''';

  // ─── AI Generation ────────────────────────────────────────────

  @override
  Future<Result<String>> generateWorkoutPlan({
    required UserEntity user,
    required int availableDays,
  }) async {
    try {
      final prompt = '''
Create a complete weekly workout plan for this person:
- Fitness Goal: ${user.fitnessGoal}
- Experience Level: ${user.fitnessLevel ?? 'Beginner'}
- Available Days Per Week: $availableDays
- Current Weight: ${user.weight != null ? '${user.weight}kg' : 'Not provided'}
- Age: ${user.age ?? 'Not provided'}
- Gender: ${user.gender ?? 'Not provided'}

Structure your response as:
1. Overview & weekly schedule (which days to train)
2. For each training day: workout name, 4-6 exercises with sets/reps
3. Rest day recommendations
4. Key progression tips for their goal
''';
      final response = await _aiDataSource.chat(_systemPrompt, prompt);
      return Result.success(response);
    } on ServerException catch (e) {
      return Result.error(ServerFailure(e.message));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<String>> getImprovementSuggestions({
    required UserEntity user,
    required List<WorkoutEntity> recentWorkouts,
  }) async {
    try {
      final completed = recentWorkouts
          .where((w) => w.status == WorkoutStatus.completed)
          .length;
      final skipped =
          recentWorkouts.where((w) => w.status == WorkoutStatus.skipped).length;
      final muscleGroups = recentWorkouts
          .expand((w) => w.exercises.map((e) => e.exercise.muscleGroup))
          .toSet()
          .toList();

      final workoutSummary = recentWorkouts.take(10).map((w) {
        return '- ${w.name} (${w.status.name}) targeting: ${w.targetDays.join(", ")}';
      }).join('\n');

      final prompt = '''
Analyze this user's recent workout history and give improvement suggestions:

User Profile:
- Goal: ${user.fitnessGoal}
- Level: ${user.fitnessLevel ?? 'Beginner'}

Recent Activity (last ${recentWorkouts.length} workouts):
$workoutSummary

Stats:
- Completed: $completed workouts
- Skipped: $skipped workouts  
- Muscle groups trained: ${muscleGroups.join(', ')}

Provide 3-5 specific, actionable improvement suggestions covering:
- Any gaps or imbalances in muscle group coverage
- Consistency patterns and how to improve
- Progressive overload recommendations
- Recovery and rest advice
''';
      final response = await _aiDataSource.chat(_systemPrompt, prompt);
      return Result.success(response);
    } on ServerException catch (e) {
      return Result.error(ServerFailure(e.message));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<String>> getDailyTip({required UserEntity user}) async {
    try {
      final hour = DateTime.now().hour;
      final timeOfDay = hour < 12
          ? 'morning'
          : hour < 17
              ? 'afternoon'
              : 'evening';

      final prompt = '''
Give one short, powerful fitness tip (2-4 sentences) for a $timeOfDay session.
User goal: ${user.fitnessGoal}
User level: ${user.fitnessLevel ?? 'Beginner'}
Vary the topic — alternate between: training technique, nutrition timing, 
sleep/recovery, mindset, hydration, or warm-up/cool-down.
Make it immediately actionable.
''';
      final response = await _aiDataSource.chat(_systemPrompt, prompt);
      return Result.success(response);
    } on ServerException catch (e) {
      return Result.error(ServerFailure(e.message));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<String>> getDietSuggestions({required UserEntity user}) async {
    try {
      final prompt = '''
Create a practical daily meal plan for someone who wants to ${user.fitnessGoal}.

User details:
- Weight: ${user.weight != null ? '${user.weight}kg' : 'Not provided'}
- Age: ${user.age ?? 'Not provided'}
- Goal: ${user.fitnessGoal}

Include:
1. Daily calorie & protein targets for their goal
2. Breakfast, morning snack, lunch, afternoon snack, dinner
3. Pre/post workout nutrition tip
4. 3 simple meal prep tips
5. Foods to prioritize and foods to limit

Keep meals realistic, affordable, and easy to prepare.
''';
      final response = await _aiDataSource.chat(_systemPrompt, prompt);
      return Result.success(response);
    } on ServerException catch (e) {
      return Result.error(ServerFailure(e.message));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<String>> chatWithAi(UserEntity user, String message) async {
    try {
      final prompt = '''
The user is asking a question related to fitness, nutrition, or general health.
User's profile:
- Fitness Goal: ${user.fitnessGoal}
- Experience Level: ${user.fitnessLevel ?? 'Beginner'}
- Current Weight: ${user.weight != null ? '${user.weight}kg' : 'Not provided'}
- Age: ${user.age ?? 'Not provided'}
- Gender: ${user.gender ?? 'Not provided'}

User's question: "$message"
Provide a helpful, concise, and accurate answer based on your expertise.
''';
      final response = await _aiDataSource.chat(_systemPrompt, prompt);
      return Result.success(response);
    } on ServerException catch (e) {
      return Result.error(ServerFailure(e.message));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  // ─── Persistence ──────────────────────────────────────────────

  @override
  Future<Result<void>> saveSuggestion(AiSuggestionEntity suggestion) async {
    try {
      // userId must come from metadata so we can query it back
      final userId = suggestion.metadata?['userId'] as String?;
      await _db.collection(AppConstants.tipsCollection).doc(suggestion.id).set({
        'userId': userId, // ← FIXED: store userId for querying
        'type': suggestion.type.name,
        'title': suggestion.title,
        'content': suggestion.content,
        'generatedAt': Timestamp.fromDate(suggestion.generatedAt),
        'isRead': suggestion.isRead,
        'metadata': suggestion.metadata,
      });
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<List<AiSuggestionEntity>>> getSavedSuggestions(
    String userId,
  ) async {
    try {
      final snap = await _db
          .collection(AppConstants.tipsCollection)
          .where('userId', isEqualTo: userId) // ← FIXED: now works correctly
          .orderBy('generatedAt', descending: true)
          .limit(20)
          .get();

      final suggestions = snap.docs.map((doc) {
        final data = doc.data();
        return AiSuggestionEntity(
          id: doc.id,
          type: SuggestionType.values.firstWhere(
            (t) => t.name == (data['type'] as String?),
            orElse: () => SuggestionType.tip,
          ),
          title: (data['title'] as String?) ?? '',
          content: (data['content'] as String?) ?? '',
          generatedAt: (data['generatedAt'] as Timestamp).toDate(),
          isRead: (data['isRead'] as bool?) ?? false,
          metadata: data['metadata'] as Map<String, dynamic>?,
        );
      }).toList();

      return Result.success(suggestions);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  // ─── Chat History ─────────────────────────────────────────────

  @override
  Future<Result<void>> saveChatMessage(ChatMessageEntity message) async {
    try {
      await _db
          .collection(AppConstants.chatCollection)
          .doc(message.id)
          .set(message.toDocument());
      return Result.success(null);
    } on FirebaseException catch (e) {
      return Result.error(
          ServerFailure(e.message ?? 'Firebase error saving chat message'));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<List<ChatMessageEntity>>> getChatHistory(String userId) async {
    try {
      final querySnapshot = await _db
          .collection(AppConstants.chatCollection)
          .where('userId', isEqualTo: userId)
          .orderBy('timestamp',
              descending: false) // Order by timestamp for chat flow
          .limit(50) // Limit history to a reasonable number
          .get();

      final messages = querySnapshot.docs.map((doc) {
        return ChatMessageEntity.fromDocument(doc.data(), doc.id);
      }).toList();

      return Result.success(messages);
    } on FirebaseException catch (e) {
      return Result.error(
          ServerFailure(e.message ?? 'Firebase error getting chat history'));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> deleteChatMessage(String messageId) async {
    try {
      await _db.collection(AppConstants.chatCollection).doc(messageId).delete();
      return Result.success(null);
    } on FirebaseException catch (e) {
      return Result.error(
          ServerFailure(e.message ?? 'Firebase error deleting chat message'));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> clearChatHistory(String userId) async {
    try {
      final batch = _db.batch();
      final querySnapshot = await _db
          .collection(AppConstants.chatCollection)
          .where('userId', isEqualTo: userId)
          .get();
      for (var doc in querySnapshot.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
      return Result.success(null);
    } on FirebaseException catch (e) {
      return Result.error(
          ServerFailure(e.message ?? 'Firebase error clearing chat history'));
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }
}
