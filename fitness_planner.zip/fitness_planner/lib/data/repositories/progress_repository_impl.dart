import 'package:fitness_planner/core/errors/exception_mapper.dart';
import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/data/datasources/firestore_datasource.dart';
import 'package:fitness_planner/data/models/progress_model.dart';
import 'package:fitness_planner/domain/entities/progress_entry_entity.dart';
import 'package:fitness_planner/domain/repositories/progress_repository.dart';

class ProgressRepositoryImpl implements ProgressRepository {
  final FirestoreDataSource _dataSource;
  ProgressRepositoryImpl(this._dataSource);

  @override
  Stream<List<ProgressEntryEntity>> watchProgress(String userId) =>
      _dataSource.watchProgress(userId);

  @override
  Future<Result<List<ProgressEntryEntity>>> getProgressEntries(
    String userId, {
    DateTime? from,
    DateTime? to,
  }) async {
    try {
      final entries =
          await _dataSource.getProgressEntries(userId, from: from, to: to);
      return Result.success(entries);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<ProgressEntryEntity>> addProgressEntry(
    ProgressEntryEntity entry,
  ) async {
    try {
      final model = ProgressModel(
        id: entry.id,
        userId: entry.userId,
        date: entry.date,
        weight: entry.weight,
        bodyFatPercent: entry.bodyFatPercent,
        chestCm: entry.chestCm,
        waistCm: entry.waistCm,
        hipsCm: entry.hipsCm,
        armCm: entry.armCm,
        thighCm: entry.thighCm,
        notes: entry.notes,
      );
      final saved = await _dataSource.addProgressEntry(model);
      return Result.success(saved);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> deleteProgressEntry(String id) async {
    try {
      await _dataSource.deleteProgressEntry(id);
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }
}
