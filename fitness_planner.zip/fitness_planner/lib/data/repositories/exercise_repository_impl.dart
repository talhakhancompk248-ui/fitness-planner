import 'package:fitness_planner/core/errors/exception_mapper.dart';
import 'package:fitness_planner/core/errors/exceptions.dart';
import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/data/datasources/firestore_datasource.dart';
import 'package:fitness_planner/data/models/exercise_model.dart';
import 'package:fitness_planner/domain/entities/exercise_entity.dart';
import 'package:fitness_planner/domain/repositories/exercise_repository.dart';

class ExerciseRepositoryImpl implements ExerciseRepository {
  final FirestoreDataSource _dataSource;
  ExerciseRepositoryImpl(this._dataSource);

  @override
  Future<Result<List<ExerciseEntity>>> getExercises({
    String? muscleGroup,
    String? equipment,
    String? difficulty,
    String? query,
  }) async {
    try {
      final exercises = await _dataSource.getExercises(
        muscleGroup: muscleGroup,
        equipment: equipment,
        difficulty: difficulty,
        query: query,
      );
      return Result.success(exercises);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<ExerciseEntity>> getExerciseById(String id) async {
    try {
      final exercises = await _dataSource.getExercises();
      final exercise = exercises.firstWhere(
        (e) => e.id == id,
        orElse: () => throw const NotFoundException('Exercise not found'),
      );
      return Result.success(exercise);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<ExerciseEntity>> createCustomExercise(
    ExerciseEntity exercise,
  ) async {
    try {
      final model = ExerciseModel(
        id: exercise.id,
        name: exercise.name,
        muscleGroup: exercise.muscleGroup,
        equipment: exercise.equipment,
        difficulty: exercise.difficulty,
        description: exercise.description,
        imageUrl: exercise.imageUrl,
        instructions: exercise.instructions,
        isCustom: true,
        createdBy: exercise.createdBy,
      );
      final created = await _dataSource.createCustomExercise(model);
      return Result.success(created);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> deleteCustomExercise(String id) async {
    try {
      await _dataSource.deleteCustomExercise(id);
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<List<ExerciseEntity>>> getCustomExercises(
    String userId,
  ) async {
    try {
      final all = await _dataSource.getExercises();
      final custom =
          all.where((e) => e.isCustom && e.createdBy == userId).toList();
      return Result.success(custom);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }
}
