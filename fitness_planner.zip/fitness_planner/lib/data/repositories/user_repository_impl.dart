import 'package:fitness_planner/core/errors/exception_mapper.dart';
import 'package:fitness_planner/core/utils/result.dart';
import 'package:fitness_planner/data/datasources/firestore_datasource.dart';
import 'package:fitness_planner/data/models/user_model.dart';
import 'package:fitness_planner/domain/entities/user_entity.dart';
import 'package:fitness_planner/domain/repositories/user_repository.dart';

class UserRepositoryImpl implements UserRepository {
  final FirestoreDataSource _dataSource;
  UserRepositoryImpl(this._dataSource);

  @override
  Future<Result<UserEntity>> getUserProfile(String userId) async {
    try {
      final user = await _dataSource.getUserProfile(userId);
      return Result.success(user);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> updateUserProfile(UserEntity user) async {
    try {
      await _dataSource.setUserProfile(UserModel.fromEntity(user));
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }

  @override
  Future<Result<void>> createUserProfile(UserEntity user) async {
    try {
      await _dataSource.setUserProfile(UserModel.fromEntity(user));
      return Result.success(null);
    } catch (e) {
      return Result.error(ExceptionMapper.toFailure(e));
    }
  }
}
