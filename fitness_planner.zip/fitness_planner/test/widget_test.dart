// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:fitness_planner/main.dart';

void main() {
  testWidgets('App starts without crashing', (WidgetTester tester) async {
    // Note: In a real integration test, you would set up Firebase emulator
    // For now, this test just verifies the widget tree builds
    await tester.pumpWidget(const FitnessApp());

    // Verify the app started
    expect(find.byType(MaterialApp), findsWidgets);
  });
}
